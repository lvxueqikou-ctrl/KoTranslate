-- Persistent plugin state: configuration and the single-book translation queue.
-- This module deliberately contains no translation or EPUB logic.
local DataStorage = require("datastorage")
local UIManager = require("ui/uimanager")
local InfoMessage = require("ui/widget/infomessage")
local logger = require("logger")
local DocumentAdapter = require("kotranslate_document_adapter")

local State = {}

local function serialize(value, indent)
    indent = indent or ""
    local kind = type(value)
    if kind == "string" then return string.format("%q", value) end
    if kind == "number" or kind == "boolean" then return tostring(value) end
    if kind ~= "table" then return "nil" end

    local entries = {}
    local next_indent = indent .. "    "
    for key, item in pairs(value) do
        local key_text = type(key) == "string"
            and string.format("[%q]", key)
            or "[" .. tostring(key) .. "]"
        table.insert(entries, next_indent .. key_text .. " = " .. serialize(item, next_indent) .. ",")
    end
    table.sort(entries)
    return "{\n" .. table.concat(entries, "\n") .. "\n" .. indent .. "}"
end

function State.getQueuePath()
    local directory = DataStorage:getDataDir() .. "/cache/kotranslate"
    os.execute("mkdir -p " .. string.format("%q", directory))
    return directory .. "/translation_queue.lua"
end

function State.loadConfig(plugin)
    local ok, config = pcall(dofile, plugin.config_path)
    plugin.config = ok and type(config) == "table" and config or {}
    if not ok then logger.warn("kotranslate: failed to load config, using defaults") end
end

function State.saveConfig(plugin)
    local file = io.open(plugin.config_path, "w")
    if not file then
        logger.warn("kotranslate: failed to save config to", plugin.config_path)
        return
    end
    file:write("-- KoTranslate configuration\nreturn ", serialize(plugin.config), "\n")
    file:close()
end

function State.saveQueue(plugin)
    local file = io.open(State.getQueuePath(), "w")
    if not file then return false end
    file:write("return {\n")
    local keys = {
        "book_path", "fragment", "status", "error", "output", "all_chapters",
        "current", "total", "translated", "failed", "retry_count",
    }
    for _, item in ipairs(plugin._translation_queue or {}) do
        if item.book_path and item.status ~= "done" then
            file:write("    {\n")
            for _, key in ipairs(keys) do
                local value = item[key]
                if value ~= nil then
                    local kind = type(value)
                    if kind == "string" then
                        file:write(string.format("        [%q] = %q,\n", key, value))
                    elseif kind == "number" or kind == "boolean" then
                        file:write(string.format("        [%q] = %s,\n", key, tostring(value)))
                    end
                end
            end
            file:write("    },\n")
        end
    end
    file:write("}\n")
    file:close()
    return true
end

function State.loadQueue()
    local ok, value = pcall(dofile, State.getQueuePath())
    local queue = ok and type(value) == "table" and value or {}
    local pending, retried = {}, {}
    for _, item in ipairs(queue) do
        if item.status == "active" then item.status = "queued" end
        local key = tostring(item.book_path or "") .. "\0" .. tostring(item.all_chapters)
        local retryable = item.status == "failed" and item.all_chapters
            and (tonumber(item.retry_count) or 0) < 2
        if retryable and not retried[key] then
            item.status, item.error = "queued", nil
            item.retry_count = math.max(1, tonumber(item.retry_count) or 0)
            retried[key] = true
            table.insert(pending, item)
        elseif item.status ~= "done" and item.status ~= "aborting" then
            table.insert(pending, item)
        end
    end
    return pending
end

function State.findQueued(plugin, book_path, all_chapters)
    for _, item in ipairs(plugin._translation_queue or {}) do
        if item.book_path == book_path and item.all_chapters == all_chapters
            and (item.status == "queued" or item.status == "active"
                or item.status == "paused" or item.status == "aborting") then
            return item
        end
    end
end

function State.clearForBook(plugin, book_path)
    if not book_path then return true end
    if plugin._translation_progress and plugin._translation_progress.active
        and plugin._translation_progress.book_path == book_path then
        return false
    end
    local kept = {}
    for _, item in ipairs(plugin._translation_queue or {}) do
        if item.book_path == book_path then
            if item.progress_path then os.remove(item.progress_path) end
        else
            kept[#kept + 1] = item
        end
    end
    plugin._translation_queue = kept
    State.saveQueue(plugin)
    return true
end

function State.enqueue(plugin, book_path, all_chapters, fragment)
    if not book_path or not DocumentAdapter.supportsWholeBook(book_path) then
        plugin.TranslationUI.showInfo("当前格式暂不支持整书翻译")
        return
    end
    if State.findQueued(plugin, book_path, all_chapters) then
        plugin.TranslationUI.showInfo("这本书已经在翻译队列中")
        return
    end
    local item = {
        book_path = book_path,
        all_chapters = all_chapters and true or false,
        fragment = all_chapters and nil or fragment,
        status = "queued", current = 0, total = 0, translated = 0, failed = 0,
    }
    table.insert(plugin._translation_queue, item)
    State.saveQueue(plugin)
    plugin:startNextQueuedTranslation()
    if not plugin._translation_progress or plugin._translation_progress.item ~= item then
        plugin.TranslationUI.showInfo("已加入翻译队列")
    end
end

local function write_control(item, value)
    local path = item and item.control_path
    if not path then return false end
    if value == nil then
        os.remove(path)
        return true
    end
    local file = io.open(path, "wb")
    if not file then return false end
    file:write(value, "\n")
    file:close()
    return true
end

function State.removeItem(plugin, wanted)
    local kept = {}
    for _, item in ipairs(plugin._translation_queue or {}) do
        if item ~= wanted then kept[#kept + 1] = item end
    end
    plugin._translation_queue = kept
    if wanted then
        if wanted.progress_path then os.remove(wanted.progress_path) end
        if wanted.control_path then os.remove(wanted.control_path) end
    end
    State.saveQueue(plugin)
end

function State.pause(plugin, item)
    local running = plugin._translation_progress
        and plugin._translation_progress.active
        and plugin._translation_progress.item == item
    if running then
        if not write_control(item, "pause") then return false end
    end
    item.status = "paused"
    State.saveQueue(plugin)
    return true
end

function State.resume(plugin, item)
    local running = plugin._translation_progress
        and plugin._translation_progress.active
        and plugin._translation_progress.item == item
    item.error = nil
    if running then
        write_control(item, nil)
        item.status = "active"
        State.saveQueue(plugin)
    else
        item.status = "queued"
        State.saveQueue(plugin)
        plugin:startNextQueuedTranslation()
    end
    return true
end

function State.abort(plugin, item)
    local running = plugin._translation_progress
        and plugin._translation_progress.active
        and plugin._translation_progress.item == item
    if running then
        if not write_control(item, "abort") then return false end
        item.status = "aborting"
        State.saveQueue(plugin)
    else
        State.removeItem(plugin, item)
        plugin:startNextQueuedTranslation()
    end
    return true
end

function State.progress(item)
    if not item.progress_path then
        return tonumber(item.current) or 0, tonumber(item.total) or 0,
            tonumber(item.translated) or 0, tonumber(item.failed) or 0
    end
    local file = io.open(item.progress_path, "r")
    local line = file and file:read("*l") or nil
    if file then file:close() end
    local current, total, translated, failed
    if line then
        current, total, translated, failed = line:match("^(%d+)|(%d+)|(%d+)|(%d+)|")
    end
    if current then
        return tonumber(current) or 0, tonumber(total) or 0,
            tonumber(translated) or 0, tonumber(failed) or 0
    end
    return tonumber(item.current) or 0, tonumber(item.total) or 0,
        tonumber(item.translated) or 0, tonumber(item.failed) or 0
end

function State.showQueue(plugin)
    local ButtonDialog = require("ui/widget/buttondialog")
    local rows = {}
    for index, item in ipairs(plugin._translation_queue or {}) do
        if item.status ~= "done" then
            local path = tostring(item.book_path or "未知文件")
            local name = path:match("([^/]+)$") or path
            local function task_text()
                    local current, total, translated, failed = State.progress(item)
                    local status = item.status == "active" and "翻译中"
                        or item.status == "queued" and "排队中"
                        or item.status == "paused" and "已暂停"
                        or item.status == "aborting" and "正在中止"
                        or "失败"
                    return string.format("%d. %s\n%s · %d/%d · 成功 %d · 失败 %d",
                        index, name, status, current, total, translated, failed)
            end
            local row = {
                text_func = task_text,
                callback = function() end,
                hold_callback = function(button)
                    local dialog
                    local paused = item.status == "paused"
                    dialog = ButtonDialog:new{
                        title = name,
                        text = "长按任务可暂停、继续或中止。",
                        buttons = {{
                            {
                                text = paused and "继续" or "暂停",
                                enabled = item.status ~= "aborting",
                                callback = function()
                                    UIManager:close(dialog)
                                    if paused then State.resume(plugin, item)
                                    else State.pause(plugin, item) end
                                end,
                            },
                            {
                                text = "中止",
                                enabled = item.status ~= "aborting",
                                callback = function()
                                    UIManager:close(dialog)
                                    State.abort(plugin, item)
                                end,
                            },
                            {
                                text = "取消",
                                callback = function() UIManager:close(dialog) end,
                            },
                        }},
                    }
                    UIManager:show(dialog)
                end,
            }
            rows[#rows + 1] = { row }
        end
    end
    if #rows == 0 then
        UIManager:show(InfoMessage:new{ text = "暂无任务" })
        return
    end
    local dialog
    local closed = false
    dialog = ButtonDialog:new{
        title = "任务队列",
        buttons = rows,
        tap_close_callback = function() closed = true end,
    }
    UIManager:show(dialog)
    local function refresh_queue()
        if closed or not dialog or not dialog.buttontable then return end
        for row_index, row in ipairs(rows) do
            local button = dialog.buttontable.buttons_layout[row_index]
                and dialog.buttontable.buttons_layout[row_index][1]
            if button and row[1] and row[1].text_func then
                button:setText(row[1].text_func(), button.width)
                button:refresh()
            end
        end
        UIManager:scheduleIn(2, refresh_queue)
    end
    UIManager:scheduleIn(2, refresh_queue)
end

function State.startNext(plugin)
    if plugin.isPluginEnabled and not plugin:isPluginEnabled() then return end
    if plugin._translation_progress and plugin._translation_progress.active then return end
    local item
    for _, candidate in ipairs(plugin._translation_queue or {}) do
        if candidate.status == "queued" then item = candidate; break end
    end
    if not item then return end
    local source = io.open(item.book_path, "rb")
    if not source then
        item.status, item.error = "failed", "找不到原书文件"
        State.saveQueue(plugin)
        return State.startNext(plugin)
    end
    source:close()
    item.status, item.error = "active", nil
    State.saveQueue(plugin)
    plugin:_runTranslation(item)
end

function State.attach(plugin)
    plugin.TranslationUI = require("kotranslate_ui")
    plugin.getTranslationQueuePath = State.getQueuePath
    plugin.loadConfig = State.loadConfig
    plugin.saveConfig = State.saveConfig
    plugin.saveTranslationQueue = State.saveQueue
    plugin.loadTranslationQueue = State.loadQueue
    plugin.findQueuedTranslation = State.findQueued
    plugin.clearTranslationQueueForBook = State.clearForBook
    plugin.removeTranslationQueueItem = State.removeItem
    plugin.enqueueTranslation = State.enqueue
    plugin.getQueueProgress = function(_, item) return State.progress(item) end
    plugin.showTranslationQueue = State.showQueue
    plugin.startNextQueuedTranslation = State.startNext
end

return State
