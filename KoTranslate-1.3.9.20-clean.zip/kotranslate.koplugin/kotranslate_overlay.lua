-- Non-destructive, per-book inline layers for EPUB documents.
-- The original archive is never modified.  Translations and pronunciation
-- lines are persisted as JSON and exposed to CREngine as generated CSS text.

local JSON = require("json")

local Overlay = {}

local function read_file(path)
    local file = io.open(path, "rb")
    if not file then return nil end
    local data = file:read("*a")
    file:close()
    return data
end

local function write_file(path, data)
    local temporary = path .. ".tmp"
    local file = io.open(temporary, "wb")
    if not file then return false end
    file:write(data)
    file:close()
    os.remove(path)
    if not os.rename(temporary, path) then
        os.remove(temporary)
        return false
    end
    return true
end

local function css_string(value)
    value = tostring(value or "")
    value = value:gsub("\\", "\\\\"):gsub('"', '\\"')
    value = value:gsub("\r\n", "\\A "):gsub("[\r\n]", "\\A ")
    value = value:gsub("%z", "")
    return '"' .. value .. '"'
end

local function css_attribute_string(value)
    value = tostring(value or "")
    value = value:gsub("\\", "\\\\"):gsub('"', '\\"')
    value = value:gsub("\r\n", " "):gsub("[\r\n]", " ")
    value = value:gsub("%z", "")
    return '"' .. value .. '"'
end

-- Split a selector list without treating commas inside quoted attribute
-- values as separators. TXT text anchors can legitimately contain commas.
local function each_selector(value)
    local selectors, start_at, quote, escaped = {}, 1, nil, false
    local square, round = 0, 0
    for index = 1, #value do
        local character = value:sub(index, index)
        if escaped then
            escaped = false
        elseif character == "\\" and quote then
            escaped = true
        elseif quote then
            if character == quote then quote = nil end
        elseif character == '"' or character == "'" then
            quote = character
        elseif character == "[" then
            square = square + 1
        elseif character == "]" then
            square = math.max(0, square - 1)
        elseif character == "(" then
            round = round + 1
        elseif character == ")" then
            round = math.max(0, round - 1)
        elseif character == "," and square == 0 and round == 0 then
            selectors[#selectors + 1] = value:sub(start_at, index - 1)
            start_at = index + 1
        end
    end
    selectors[#selectors + 1] = value:sub(start_at)
    return ipairs(selectors)
end

function Overlay.load(path)
    local raw = read_file(path)
    if not raw or raw == "" then return nil end
    local ok, data = pcall(JSON.decode, raw)
    if not ok or type(data) ~= "table" or type(data.entries) ~= "table" then
        return nil
    end
    return data
end

function Overlay.save(path, data)
    local ok, encoded = pcall(JSON.encode, data)
    if not ok or not encoded then return false end
    return write_file(path, encoded)
end

function Overlay.exists(path)
    local file = io.open(path, "rb")
    if not file then return false end
    local size = file:seek("end") or 0
    file:close()
    return size > 0
end

-- CREngine implements generated ::before/::after content as real layout
-- nodes.  It therefore participates in pagination without touching EPUB
-- XHTML.  Rebuilding this CSS only changes the visible layers.
function Overlay.buildCss(path, options)
    local data = Overlay.load(path)
    if not data then return "" end
    options = options or {}
    local translation_visible = options.translation_visible == true
    local translation_color = options.translation_color or "#666666"
    local translation_size = options.translation_size or "1em"
    local translation_font_family = options.translation_font_family or "inherit"
    -- CREngine's TXT importer emits paragraphs as a single text flow.  A
    -- block-level pseudo element attached to that paragraph may disappear
    -- when a long generated translation crosses a page boundary.  Keep TXT
    -- translations in the paragraph flow and start them on a new line so
    -- CREngine can paginate the complete text normally.
    local book_path = tostring(data.book_path or ""):lower()
    local txt_inline_flow = book_path:match("%.txt$") ~= nil
    local exact_txt_entries = {}
    if txt_inline_flow then
        -- Repair existing overlays too: an old contains selector for a short
        -- heading can also match a longer paragraph and, because both target
        -- ::after, replace that paragraph's translation.  Force the contained
        -- source to an exact paragraph match without requiring retranslation.
        for index, entry in ipairs(data.entries) do
            local source = tostring(entry.source or "")
            if source ~= "" then
                for other_index, other in ipairs(data.entries) do
                    local other_source = tostring(other.source or "")
                    if index ~= other_index and other_source:find(source, 1, true) then
                        exact_txt_entries[index] = true
                        break
                    end
                end
            end
        end
    end
    local rules = {
        "/* KOTranslate non-destructive generated layers */",
    }
    for entry_index, entry in ipairs(data.entries) do
        local selector = entry.selector
        if exact_txt_entries[entry_index] then
            selector = "p[_=" .. css_attribute_string(entry.source) .. "]"
        end
        if selector and selector ~= "" then
            if translation_visible and entry.translation and entry.translation ~= "" then
                -- Keep each TXT fallback as its own rule.  Older CRE CSS
                -- parsers can reject a selector list combined with ::after,
                -- which would hide both alternatives.
                for _, single_selector in each_selector(selector) do
                    single_selector = single_selector:gsub("^%s+", "")
                        :gsub("%s+$", "")
                    local content = entry.translation
                    local display = "block"
                    if txt_inline_flow then
                        content = "\n" .. content
                        display = "inline"
                    end
                    table.insert(rules, string.format(
                        "%s::after{content:%s!important;display:%s!important;white-space:pre-wrap!important;color:%s!important;font-size:%s!important;font-family:%s!important;line-height:130%%!important;margin:0!important;padding:0!important;}",
                        single_selector, css_string(content), display, translation_color,
                        translation_size, translation_font_family))
                end
            end
        end
    end
    return table.concat(rules, "\n")
end

return Overlay
