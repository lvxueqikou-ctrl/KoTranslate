-- The small, keyless provider core used by KoTranslate.
local http = require("socket.http")
local ltn12 = require("ltn12")
local json = require("json")
local logger = require("logger")
local socketutil = require("socketutil")
local _ = require("gettext")

local Providers = {}

Providers.list = {
    { id = "google_free", name = "Google（免费）", requires_api_key = false,
      description = _("Google Translate web endpoint (no API key)") },
    { id = "microsoft_free", name = "Microsoft Edge（免费）", requires_api_key = false,
      description = _("Microsoft Edge web endpoint (no API key)") },
}

local function httpRequest(method, url, body, headers)
    local response_body = {}
    headers = headers or {}
    headers["Accept"] = headers["Accept"] or "application/json"
    if body and not headers["Content-Length"] then
        headers["Content-Length"] = tostring(#body)
    end
    socketutil:set_timeout(15, 15)
    local code, resp_headers, status = http.request{
        url = url, method = method, headers = headers,
        source = body and ltn12.source.string(body) or nil,
        sink = ltn12.sink.table(response_body),
    }
    socketutil:reset_timeout()
    local raw = table.concat(response_body)
    local ok, data = pcall(json.decode, raw)
    if not ok or not data then
        logger.warn("kotranslate: provider HTTP error", code, status, raw:sub(1, 160))
        return nil, { code = code,
            message = (not code or code == 1)
                and "翻译服务连接失败，请检查网络"
                or string.format("翻译服务返回 HTTP %s", tostring(code)) }
    end
    if data.error then
        local message = type(data.error) == "table" and data.error.message or data.error
        return nil, { code = code, message = tostring(message or "翻译服务错误") }
    end
    return data
end

local function urlEncode(value)
    return require("socket.url").escape(tostring(value or ""))
end

local function jsonPost(url, payload)
    return httpRequest("POST", url, json.encode(payload), {
        ["Content-Type"] = "application/json",
    })
end

function Providers.translate_microsoft_free(text, source_lang, target_lang)
    local url = "https://edge.microsoft.com/translate/translatetext?isEnterpriseClient=false&to="
        .. urlEncode(target_lang)
    if source_lang and source_lang ~= "auto" then
        url = url .. "&from=" .. urlEncode(source_lang)
    end
    local data, err = jsonPost(url, { text })
    if not data then return nil, err end
    if data[1] and data[1].translations and data[1].translations[1] then
        return { translated_text = data[1].translations[1].text,
            source_lang = source_lang, target_lang = target_lang,
            provider = "microsoft_free" }
    end
    return nil, { message = _("Microsoft Edge returned no translation") }
end

function Providers.translate_microsoft_free_batch(texts, source_lang, target_lang)
    local url = "https://edge.microsoft.com/translate/translatetext?isEnterpriseClient=false&to="
        .. urlEncode(target_lang)
    if source_lang and source_lang ~= "auto" then
        url = url .. "&from=" .. urlEncode(source_lang)
    end
    local data, err = jsonPost(url, texts)
    if not data then return nil, err end
    local result = {}
    for index, item in ipairs(data) do
        if not item.translations or not item.translations[1]
            or not item.translations[1].text then
            return nil, { message = _("Microsoft Edge returned an incomplete batch") }
        end
        result[index] = item.translations[1].text
    end
    if #result ~= #texts then
        return nil, { message = _("Microsoft Edge returned an incomplete batch") }
    end
    return result
end

function Providers.translate_google_free(text, source_lang, target_lang)
    local url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl="
        .. urlEncode(source_lang or "auto") .. "&tl=" .. urlEncode(target_lang)
        .. "&dt=t&dj=1&q=" .. urlEncode(text)
    local data, err = httpRequest("GET", url, nil, {})
    if not data then return nil, err end
    if data.sentences then
        local parts = {}
        for _, sentence in ipairs(data.sentences) do
            if sentence.trans then parts[#parts + 1] = sentence.trans end
        end
        if #parts > 0 then
            return { translated_text = table.concat(parts), source_lang = source_lang,
                target_lang = target_lang, provider = "google_free" }
        end
    end
    return nil, { message = _("Google returned no translation") }
end

function Providers.translate(provider_id, text, source_lang, target_lang)
    if provider_id == "microsoft_free" then
        return Providers.translate_microsoft_free(text, source_lang, target_lang)
    elseif provider_id == "google_free" then
        return Providers.translate_google_free(text, source_lang, target_lang)
    end
    return nil, { message = "未知翻译服务，请选择 Google 或 Microsoft Edge" }
end

function Providers.getProviderById(id)
    for _, provider in ipairs(Providers.list) do
        if provider.id == id then return provider end
    end
end

function Providers.getProviderName(id)
    local provider = Providers.getProviderById(id)
    return provider and provider.name or "Microsoft Edge（免费）"
end

return Providers
