# KoTranslate

轻量的 KOReader 翻译与辅助阅读插件。

## 翻译服务

插件只保留两个无需 API 密钥的在线服务：

- Microsoft Edge（免费）：支持整书批量翻译，默认服务。
- Google（免费）：逐段翻译备用。

插件不包含付费 API、离线伴侣、MyMemory、Lingva、LibreTranslate 或重复的 Google 接口。

## 功能

- 在原书上建立独立的译文覆盖层，不修改或重新打包原文件。
- EPUB、FB2、TXT 支持整书译文。
- 整书翻译可在队列中续跑；短按任务不再弹出重复进度框，长按可暂停、继续或中止。
- 可随时显示或隐藏译文。
- 英语考试词表辅助阅读（CET4、CET6、专八、TOEFL、IELTS），选择后自动后台下载对应的小型释义词典（约 0.5–2.5 MB）；带释义的单词以浅色下划线标记。
- 日语汉字假名和罗马音，可分别勾选，也可同时显示。
- 辅助阅读字号和颜色可独立调整。
- 清除本书译文时，同时删除覆盖层、缓存和遗留翻译任务。
- 日语保留插件内置单字读音兜底；“辅助阅读 → 日文 → 字典”可联网下载更完整的日文读音词典。

## 配置

配置文件：`kotranslate_configuration.lua`

常用选项：

```lua
return {
    ["mode"] = "microsoft_free", -- microsoft_free 或 google_free
    ["source_lang"] = "auto",
    ["target_lang"] = "zh",
    ["enable_cache"] = true,
    ["assist_reading"] = true,
    ["assist_font_size"] = 40,
    ["assist_color"] = "#4d4d4d",
}
```

## 数据位置

译文数据库位于 KOReader 数据目录的 `kotranslate_cache.sqlite3`；每本书的覆盖层位于 `cache/kotranslate/books/`。原书始终保持不变。

## 使用

主菜单提供“生成译文（本书）”“生成译文（本章）”“中文译文”“辅助阅读”“设置与数据”。词典直接放在“辅助阅读”中；翻译服务、语言、译文样式、任务队列和删除功能集中在“设置与数据”中。

顶层“KoTranslate”菜单项带有启用复选框。短按进入菜单，长按启用或停用插件；停用不会删除译文、词典、队列或细项设置。
