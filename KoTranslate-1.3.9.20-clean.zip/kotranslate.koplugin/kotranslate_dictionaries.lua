-- Small, device-neutral dictionary downloads.
-- Downloads run in a KOReader subprocess through LuaSocket, so this module
-- does not depend on device-specific paths or external download programs.

local DataStorage = require("datastorage")
local UIManager = require("ui/uimanager")
local InfoMessage = require("ui/widget/infomessage")
local FFIUtil = require("ffi/util")
local JSON = require("json")
local lfs = require("libs/libkoreader-lfs")

local Dictionaries = {}

local RELEASE = "20260822"
local JAPANESE_URLS = {
    "https://ghproxy.net/https://github.com/xxyzz/wiktionary_stardict/releases/download/"
        .. RELEASE .. "/ja-en.tar.zst",
    "https://gh-proxy.com/https://github.com/xxyzz/wiktionary_stardict/releases/download/"
        .. RELEASE .. "/ja-en.tar.zst",
    "https://github.com/xxyzz/wiktionary_stardict/releases/download/"
        .. RELEASE .. "/ja-en.tar.zst",
}

local exam_base = "https://cdn.jsdelivr.net/gh/monojson/qwerty-learner@main/public/dicts/"
local english_exams = {
    cet4 = { id = "english-cet4", label = "CET4", file = "cet4.tsv",
        size = 499501, urls = { exam_base .. "CET4_T.json" } },
    cet6 = { id = "english-cet6", label = "CET6", file = "cet6.tsv",
        size = 481442, urls = { exam_base .. "CET6_T.json" } },
    tem8 = { id = "english-tem8", label = "专八", file = "tem8.tsv",
        size = 2513478, urls = { exam_base .. "Level8luan_2_T.json" } },
    toefl = { id = "english-toefl", label = "TOEFL", file = "toefl.tsv",
        size = 814216, urls = { exam_base .. "TOEFL_3_T.json" } },
    ielts = { id = "english-ielts", label = "IELTS", file = "ielts.tsv",
        size = 676470, urls = { exam_base .. "IELTS_3_T.json" } },
}

local japanese = {
    id = "ja-en", label = "日文读音词典", file = "ja-en.tar.zst",
    archive = true, urls = JAPANESE_URLS,
}

local function quote(value)
    return "'" .. tostring(value):gsub("'", "'\\''") .. "'"
end

local function notify(text, timeout)
    UIManager:show(InfoMessage:new{ text = text, timeout = timeout or 3 })
end

local function data_root()
    return DataStorage:getDataDir()
end

local function cache_dir()
    return data_root() .. "/cache/kotranslate/dictionaries"
end

local function english_dir()
    return data_root() .. "/data/kotranslate/english"
end

local function dictionary_dir()
    return data_root() .. "/data/dict"
end

local function target_path(item)
    if item.archive then return cache_dir() .. "/" .. item.file end
    return english_dir() .. "/" .. item.file
end

local function job_paths(item)
    return {
        target = target_path(item),
        temporary = target_path(item) .. ".part",
        state = cache_dir() .. "/" .. item.id .. ".state",
        error = cache_dir() .. "/" .. item.id .. ".error",
    }
end

local function read_line(path)
    local file = io.open(path, "rb")
    if not file then return nil end
    local value = file:read("*l")
    file:close()
    return value
end

local function write_line(path, value)
    local file = io.open(path, "wb")
    if not file then return false end
    file:write(tostring(value), "\n")
    file:close()
    return true
end

local function japanese_installed()
    local dir = dictionary_dir()
    local pipe = io.popen("find " .. quote(dir)
        .. " -maxdepth 3 -type f -name '*ja-en*.ifo' 2>/dev/null")
    if not pipe then return false end
    local found = pipe:read("*l")
    pipe:close()
    return found ~= nil and found ~= ""
end

local function is_installed(item)
    if item.archive then return japanese_installed() end
    local attr = lfs.attributes(target_path(item))
    return attr and attr.mode == "file" and (tonumber(attr.size) or 0) > 100
end

local function job_status(item)
    if is_installed(item) then return "installed", 100 end
    local paths = job_paths(item)
    local state = read_line(paths.state)
    if state == "extracting" or state == "error" then return state end
    if state ~= "downloading" then return "idle" end
    local temporary = lfs.attributes(paths.temporary)
    local running_here = Dictionaries._item == item and Dictionaries._pid
        and not FFIUtil.isSubProcessDone(Dictionaries._pid)
    -- Old releases left a "downloading" marker and curl pid behind when the
    -- process had already died. Do not let that stale marker permanently
    -- block a new compact dictionary download.
    if not temporary and not running_here then return "idle" end
    local size = tonumber((temporary or {}).size) or 0
    local percent
    if item.size and item.size > 0 then
        percent = math.max(0, math.min(99, math.floor(size * 100 / item.size)))
    end
    return state, percent, size
end

local function status_text(item, label)
    label = label or item.label
    local state, percent, size = job_status(item)
    if state == "installed" then return "✓ " .. label end
    if state == "extracting" then return "… 安装中：" .. label end
    if state == "error" then return "! 下载失败：" .. label end
    if state == "downloading" then
        local progress = percent and (tostring(percent) .. "%")
            or string.format("%.1f MB", (size or 0) / 1048576)
        return "↓ 下载中 " .. progress .. "：" .. label
    end
    return "↓ " .. label
end

local function download_to_file(url, path)
    local ltn12 = require("ltn12")
    local socket = require("socket")
    local socketutil = require("socketutil")
    local transport = url:match("^https://") and require("ssl.https")
        or require("socket.http")
    local file, open_error = io.open(path, "wb")
    if not file then return false, tostring(open_error) end
    socketutil:set_timeout(30, 300)
    local request = {
        url = url,
        method = "GET",
        headers = { ["User-Agent"] = "KOReader-KoTranslate/1.3" },
        sink = ltn12.sink.file(file),
    }
    if not url:match("^https://") then request.redirect = true end
    local code, _, status = socket.skip(1, transport.request(request))
    socketutil:reset_timeout()
    if code == 200 then return true end
    os.remove(path)
    return false, tostring(status or code or "network error")
end

local function compact_english_dictionary(source, target)
    local input, open_error = io.open(source, "rb")
    if not input then return false, tostring(open_error) end
    local content = input:read("*a")
    input:close()
    local ok, entries = pcall(JSON.decode, content)
    if not ok or type(entries) ~= "table" then return false, "词典数据无效" end
    local output
    output, open_error = io.open(target, "wb")
    if not output then return false, tostring(open_error) end
    local count = 0
    for _, entry in ipairs(entries) do
        local word = type(entry) == "table" and tostring(entry.name or ""):lower() or ""
        local translations = type(entry) == "table" and entry.trans or nil
        local gloss = type(translations) == "table" and translations[1] or nil
        if word:match("^[a-z][a-z'%-]*$") and type(gloss) == "string" then
            gloss = gloss:gsub("[\r\n\t]+", " "):gsub("^%s+", ""):gsub("%s+$", "")
            if gloss ~= "" then
                output:write(word, "\t", gloss, "\n")
                count = count + 1
            end
        end
    end
    output:close()
    if count == 0 then
        os.remove(target)
        return false, "词典中没有有效词条"
    end
    return true
end

local function find_executable(names)
    for _, name in ipairs(names) do
        if name:find("/", 1, true) then
            if lfs.attributes(name, "mode") == "file" then return name end
        else
            local pipe = io.popen("command -v " .. name .. " 2>/dev/null")
            local found = pipe and pipe:read("*l") or nil
            if pipe then pipe:close() end
            if found and found ~= "" then return found end
        end
    end
end

local function extract_japanese(archive)
    local root = data_root()
    local zstd = find_executable({ "zstd", root .. "/zstd", "/usr/bin/zstd" })
    local tar = find_executable({ "tar", root .. "/tar", "/bin/tar" })
    if not zstd or not tar then return false, "设备缺少 zstd 或 tar" end
    local command = quote(zstd) .. " -q -d -c " .. quote(archive)
        .. " | " .. quote(tar) .. " -x -C " .. quote(dictionary_dir())
    local result = os.execute(command)
    return result == true or result == 0, "词典解压失败"
end

local function start_download(item)
    if Dictionaries._pid and not FFIUtil.isSubProcessDone(Dictionaries._pid) then
        return false, "已有词典正在下载"
    end
    local paths = job_paths(item)
    os.execute("mkdir -p " .. quote(cache_dir()) .. " " .. quote(english_dir())
        .. " " .. quote(dictionary_dir()))
    os.remove(paths.error)
    os.remove(paths.temporary)
    -- Exact legacy job files only; current downloads no longer use them.
    os.remove(cache_dir() .. "/" .. item.id .. ".pid")
    os.remove(cache_dir() .. "/" .. item.id .. ".log")
    os.remove(cache_dir() .. "/" .. item.id .. ".total")
    write_line(paths.state, "downloading")
    local pid = FFIUtil.runInSubProcess(function()
        local ok, err
        for _, url in ipairs(item.urls) do
            ok, err = download_to_file(url, paths.temporary)
            if ok then break end
        end
        if not ok then
            write_line(paths.error, err or "下载失败")
            write_line(paths.state, "error")
            return
        end
        if item.archive then
            write_line(paths.state, "extracting")
            os.rename(paths.temporary, paths.target)
            ok, err = extract_japanese(paths.target)
            if ok then os.remove(paths.target) end
        else
            ok, err = compact_english_dictionary(paths.temporary, paths.target)
            os.remove(paths.temporary)
        end
        if ok then
            write_line(paths.state, "done")
        else
            write_line(paths.error, err or "安装失败")
            write_line(paths.state, "error")
        end
    end)
    if not pid then
        write_line(paths.state, "error")
        return false, "无法启动后台任务"
    end
    Dictionaries._pid = pid
    Dictionaries._item = item
    UIManager:preventStandby()
    return true
end

local function monitor(item, menu, on_installed)
    if Dictionaries._monitor_scheduled then return end
    Dictionaries._monitor_scheduled = true
    local function poll()
        if menu and menu.updateItems then pcall(function() menu:updateItems() end) end
        local state = job_status(item)
        local done = Dictionaries._pid and FFIUtil.isSubProcessDone(Dictionaries._pid)
        if state == "installed" or state == "error" or done then
            Dictionaries._monitor_scheduled = nil
            Dictionaries._pid = nil
            Dictionaries._item = nil
            UIManager:allowStandby()
            if state == "installed" then
                if on_installed then pcall(on_installed) end
                notify("词典已安装：" .. item.label, 4)
            else
                local reason = read_line(job_paths(item).error) or "下载失败"
                notify("词典下载失败：" .. item.label .. "\n" .. reason, 6)
            end
            return
        end
        UIManager:scheduleIn(1, poll)
    end
    UIManager:scheduleIn(1, poll)
end

function Dictionaries.download(item, menu, on_installed)
    local state = job_status(item)
    if state == "installed" then
        if on_installed then pcall(on_installed) end
        notify("词典已经安装：" .. item.label)
        return
    end
    if state == "downloading" or state == "extracting" then
        notify(status_text(item))
        monitor(item, menu, on_installed)
        return
    end
    local started, reason = start_download(item)
    if not started then
        notify(reason or "无法开始下载", 5)
        return
    end
    notify("已开始后台下载，可继续阅读。", 3)
    monitor(item, menu, on_installed)
end

function Dictionaries.buildMenu(on_installed, display_label)
    return {{
        text_func = function() return status_text(japanese, display_label) end,
        keep_menu_open = true,
        callback = function(menu) Dictionaries.download(japanese, menu, on_installed) end,
    }}
end

function Dictionaries.englishExamStatus(profile, label)
    local item = english_exams[profile]
    return item and status_text(item, label or item.label) or tostring(label or profile)
end

function Dictionaries.downloadEnglishExam(profile, menu, on_installed)
    local item = english_exams[profile]
    if item then Dictionaries.download(item, menu, on_installed) end
end

return Dictionaries
