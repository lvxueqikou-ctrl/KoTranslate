local DataStorage = require("datastorage")
local SQ3 = require("lua-ljsqlite3/init")
local logger = require("logger")

local DB_FILENAME = "kotranslate_cache.sqlite3"

local Cache = {}

function Cache:new(o)
    o = o or {}
    setmetatable(o, self)
    self.__index = self
    return o
end

function Cache:getDbPath()
    return DataStorage:getDataDir() .. "/" .. DB_FILENAME
end

function Cache:open()
    if self.db then return self.db end
    local db_path = self:getDbPath()
    local db = SQ3.open(db_path)
    db:exec("PRAGMA journal_mode=WAL;")
    db:exec("PRAGMA busy_timeout=5000;")
    db:exec("PRAGMA synchronous=NORMAL;")
    db:exec([[
        CREATE TABLE IF NOT EXISTS translations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_lang TEXT NOT NULL,
            target_lang TEXT NOT NULL,
            source_text TEXT NOT NULL,
            translated_text TEXT NOT NULL,
            provider TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            last_used_at INTEGER NOT NULL,
            use_count INTEGER DEFAULT 1,
            book_path TEXT,
            UNIQUE(source_lang, target_lang, source_text)
        );
    ]])
    db:exec([[
        CREATE INDEX IF NOT EXISTS idx_translations_lookup
            ON translations(source_lang, target_lang, source_text);
    ]])
    db:exec([[
        CREATE INDEX IF NOT EXISTS idx_translations_book
            ON translations(book_path);
    ]])
    db:exec([[
        CREATE TABLE IF NOT EXISTS annotations (
            kind TEXT NOT NULL,
            source_text TEXT NOT NULL,
            annotation TEXT,
            created_at INTEGER NOT NULL,
            PRIMARY KEY(kind, source_text)
        );
    ]])
    -- Whole-book translations are deliberately isolated by book.  The old
    -- translations table is shared by selected-text translation and its
    -- UNIQUE key cannot represent the same paragraph in multiple books.
    db:exec([[
        CREATE TABLE IF NOT EXISTS book_translations (
            book_path TEXT NOT NULL,
            source_lang TEXT NOT NULL,
            target_lang TEXT NOT NULL,
            source_text TEXT NOT NULL,
            translated_text TEXT NOT NULL,
            provider TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            last_used_at INTEGER NOT NULL,
            use_count INTEGER DEFAULT 1,
            PRIMARY KEY(book_path, source_lang, target_lang, source_text)
        );
    ]])
    self.db = db
    return db
end

function Cache:lookupForBook(book_path, source_lang, target_lang, source_text)
    if not book_path then return nil end
    local db = self:open()
    local stmt = db:prepare([[
        SELECT translated_text, provider FROM book_translations
        WHERE book_path = ? AND source_lang = ? AND target_lang = ? AND source_text = ?
        LIMIT 1
    ]])
    stmt:bind(book_path, source_lang, target_lang, source_text)
    local row = stmt:step()
    stmt:close()
    if not row then return nil end
    local update_stmt = db:prepare([[
        UPDATE book_translations SET last_used_at = ?, use_count = use_count + 1
        WHERE book_path = ? AND source_lang = ? AND target_lang = ? AND source_text = ?
    ]])
    update_stmt:bind(os.time(), book_path, source_lang, target_lang, source_text)
    update_stmt:step()
    update_stmt:close()
    return { translated_text = row[1], provider = row[2], cached = true }
end

function Cache:storeForBook(book_path, source_lang, target_lang, source_text,
        translated_text, provider)
    if not book_path then return false end
    local db = self:open()
    local now = os.time()
    local stmt = db:prepare([[
        INSERT OR REPLACE INTO book_translations
            (book_path, source_lang, target_lang, source_text, translated_text,
             provider, created_at, last_used_at, use_count)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
    ]])
    stmt:bind(book_path, source_lang, target_lang, source_text, translated_text,
        provider, now, now)
    local ok, err = pcall(function() stmt:step() end)
    stmt:close()
    if not ok then logger.warn("kotranslate: book cache store error:", err) end
    return ok
end

function Cache:lookupAnnotation(kind, source_text)
    local db = self:open()
    local stmt = db:prepare([[
        SELECT annotation FROM annotations
        WHERE kind = ? AND source_text = ?
        LIMIT 1
    ]])
    stmt:bind(kind, source_text)
    local row = stmt:step()
    stmt:close()
    if row then
        return row[1] ~= "" and row[1] or nil
    end
    return nil
end

function Cache:storeAnnotation(kind, source_text, annotation)
    local db = self:open()
    local stmt = db:prepare([[
        INSERT OR REPLACE INTO annotations(kind, source_text, annotation, created_at)
        VALUES (?, ?, ?, ?)
    ]])
    stmt:bind(kind, source_text, annotation or "", os.time())
    local ok, err = pcall(function() stmt:step() end)
    stmt:close()
    if not ok then
        logger.warn("kotranslate: annotation cache store error:", err)
    end
    return ok
end

function Cache:close()
    if self.db then
        self.db:close()
        self.db = nil
    end
end

function Cache:lookup(source_lang, target_lang, source_text)
    local db = self:open()
    local stmt = db:prepare([[
        SELECT translated_text, provider FROM translations
        WHERE source_lang = ? AND target_lang = ? AND source_text = ?
        LIMIT 1
    ]])
    stmt:bind(source_lang, target_lang, source_text)
    local row = stmt:step()
    stmt:close()
    if row then
        -- Update usage stats
        local now = os.time()
        local update_stmt = db:prepare([[
            UPDATE translations SET last_used_at = ?, use_count = use_count + 1
            WHERE source_lang = ? AND target_lang = ? AND source_text = ?
        ]])
        update_stmt:bind(now, source_lang, target_lang, source_text)
        update_stmt:step()
        update_stmt:close()
        return {
            translated_text = row[1],
            provider = row[2],
            cached = true,
        }
    end
    return nil
end

function Cache:store(source_lang, target_lang, source_text, translated_text, provider, book_path)
    local db = self:open()
    local now = os.time()
    local stmt = db:prepare([[
        INSERT OR REPLACE INTO translations
            (source_lang, target_lang, source_text, translated_text, provider, created_at, last_used_at, use_count, book_path)
        VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)
    ]])
    stmt:bind(source_lang, target_lang, source_text, translated_text, provider, now, now, book_path)
    local ok, err = pcall(function() stmt:step() end)
    stmt:close()
    if not ok then
        logger.warn("kotranslate: cache store error:", err)
    end
    return ok
end

function Cache:clearForBook(book_path, overlay)
    if not book_path then return end
    local db = self:open()
    local book_stmt = db:prepare("DELETE FROM book_translations WHERE book_path = ?")
    book_stmt:bind(book_path)
    book_stmt:step()
    book_stmt:close()
    local stmt = db:prepare("DELETE FROM translations WHERE book_path = ?")
    stmt:bind(book_path)
    stmt:step()
    stmt:close()

    -- Repair data written by older releases: batch results were accidentally
    -- stored as global rows with a NULL book_path.  The overlay is the exact
    -- list of source paragraphs belonging to this book, so delete those rows
    -- physically as part of clearing the book.
    if type(overlay) == "table" and type(overlay.entries) == "table" then
        local source_lang = overlay.source_lang
        local target_lang = overlay.target_lang
        if source_lang and target_lang then
            for _, entry in ipairs(overlay.entries) do
                if entry.source and entry.source ~= "" then
                    local legacy = db:prepare([[
                        DELETE FROM translations
                        WHERE source_lang = ? AND target_lang = ? AND source_text = ?
                    ]])
                    legacy:bind(source_lang, target_lang, entry.source)
                    legacy:step()
                    legacy:close()
                end
            end
        end
    end
end

return Cache
