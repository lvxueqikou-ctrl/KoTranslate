-- kotranslate Configuration
-- Edit this file on your PC to configure the plugin.
-- After editing, restart KOReader to apply changes.

return {
    ["plugin_enabled"] = true,
    ["assist_english_exam"] = false,
    ["assist_color"] = "#4d4d4d",
    ["assist_font_size"] = 40,
    ["assist_japanese_furigana"] = true,
    ["assist_japanese_romaji"] = false,
    ["assist_reading"] = true,
    ["enable_cache"] = true,
    ["inline_color"] = "#666666",
    ["inline_font_size"] = 17,
    ["mode"] = "microsoft_free",
    ["source_lang"] = "auto",
    ["target_lang"] = "zh",
    ["translation_visible"] = true,
    ["english_exam_profile"] = "cet4",
}
