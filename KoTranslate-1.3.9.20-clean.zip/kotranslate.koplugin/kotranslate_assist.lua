-- Local pronunciation helpers for the optional ruby annotations.
-- We use KOReader's installed StarDict dictionaries through sdcv so no API
-- key or translation service is needed for pronunciation data.

local DataStorage = require("datastorage")
local JSON = require("json")
local lfs = require("libs/libkoreader-lfs")
local KanjiReadings = require("kotranslate_kanji_readings")

local Assist = {}

local function shell_quote(value)
    return "'" .. tostring(value):gsub("'", "'\\''") .. "'"
end

local function shell_escape(args)
    local escaped = {}
    for _, arg in ipairs(args) do
        table.insert(escaped, shell_quote(arg))
    end
    return table.concat(escaped, " ")
end

local function utf8_chars(text)
    local chars = {}
    for char in text:gmatch("[\1-\127\194-\244][\128-\191]*") do
        table.insert(chars, char)
    end
    return chars
end

local function codepoint(char)
    local b1, b2, b3, b4 = char:byte(1, 4)
    if not b1 then return 0 end
    if b1 < 0x80 then return b1 end
    if b1 < 0xE0 then return (b1 - 0xC0) * 0x40 + (b2 - 0x80) end
    if b1 < 0xF0 then return (b1 - 0xE0) * 0x1000
        + (b2 - 0x80) * 0x40 + (b3 - 0x80) end
    return (b1 - 0xF0) * 0x40000 + (b2 - 0x80) * 0x1000
        + (b3 - 0x80) * 0x40 + (b4 - 0x80)
end

local function utf8_from_codepoint(cp)
    if cp < 0x80 then return string.char(cp) end
    if cp < 0x800 then
        return string.char(0xC0 + math.floor(cp / 0x40),
            0x80 + cp % 0x40)
    end
    if cp < 0x10000 then
        return string.char(0xE0 + math.floor(cp / 0x1000),
            0x80 + math.floor(cp / 0x40) % 0x40,
            0x80 + cp % 0x40)
    end
    return string.char(0xF0 + math.floor(cp / 0x40000),
        0x80 + math.floor(cp / 0x1000) % 0x40,
        0x80 + math.floor(cp / 0x40) % 0x40,
        0x80 + cp % 0x40)
end

local function is_cjk(cp)
    return (cp >= 0x3400 and cp <= 0x9FFF) or (cp >= 0xF900 and cp <= 0xFAFF)
end

local function is_kana(cp)
    return (cp >= 0x3040 and cp <= 0x30FF) or cp == 0x3099 or cp == 0x309A
end

local function has_cjk(text)
    for _, char in ipairs(utf8_chars(text)) do
        if is_cjk(codepoint(char)) then return true end
    end
    return false
end

local function is_kana_reading(text)
    local has_kana = false
    for _, char in ipairs(utf8_chars(text)) do
        local cp = codepoint(char)
        if is_kana(cp) then
            has_kana = true
        elseif cp ~= 0x30FB and cp ~= 0x30FC and cp ~= 0x0020 then
            return false
        end
    end
    return has_kana
end

local kana_romaji = {
    ["あ"]="a",["い"]="i",["う"]="u",["え"]="e",["お"]="o",["か"]="ka",["き"]="ki",["く"]="ku",["け"]="ke",["こ"]="ko",
    ["さ"]="sa",["し"]="shi",["す"]="su",["せ"]="se",["そ"]="so",["た"]="ta",["ち"]="chi",["つ"]="tsu",["て"]="te",["と"]="to",
    ["な"]="na",["に"]="ni",["ぬ"]="nu",["ね"]="ne",["の"]="no",["は"]="ha",["ひ"]="hi",["ふ"]="fu",["へ"]="he",["ほ"]="ho",
    ["ま"]="ma",["み"]="mi",["む"]="mu",["め"]="me",["も"]="mo",["や"]="ya",["ゆ"]="yu",["よ"]="yo",["ら"]="ra",["り"]="ri",
    ["る"]="ru",["れ"]="re",["ろ"]="ro",["わ"]="wa",["を"]="wo",["ん"]="n",["が"]="ga",["ぎ"]="gi",["ぐ"]="gu",["げ"]="ge",["ご"]="go",
    ["ざ"]="za",["じ"]="ji",["ず"]="zu",["ぜ"]="ze",["ぞ"]="zo",["だ"]="da",["ぢ"]="ji",["づ"]="zu",["で"]="de",["ど"]="do",
    ["ば"]="ba",["び"]="bi",["ぶ"]="bu",["べ"]="be",["ぼ"]="bo",["ぱ"]="pa",["ぴ"]="pi",["ぷ"]="pu",["ぺ"]="pe",["ぽ"]="po",
    ["ぁ"]="a",["ぃ"]="i",["ぅ"]="u",["ぇ"]="e",["ぉ"]="o",["ゃ"]="ya",["ゅ"]="yu",["ょ"]="yo",["っ"]="",
}
local kana_combo = {
    ["きゃ"]="kya",["きゅ"]="kyu",["きょ"]="kyo",["しゃ"]="sha",["しゅ"]="shu",["しょ"]="sho",["ちゃ"]="cha",["ちゅ"]="chu",["ちょ"]="cho",
    ["にゃ"]="nya",["にゅ"]="nyu",["にょ"]="nyo",["ひゃ"]="hya",["ひゅ"]="hyu",["ひょ"]="hyo",["みゃ"]="mya",["みゅ"]="myu",["みょ"]="myo",
    ["りゃ"]="rya",["りゅ"]="ryu",["りょ"]="ryo",["ぎゃ"]="gya",["ぎゅ"]="gyu",["ぎょ"]="gyo",["じゃ"]="ja",["じゅ"]="ju",["じょ"]="jo",
    ["びゃ"]="bya",["びゅ"]="byu",["びょ"]="byo",["ぴゃ"]="pya",["ぴゅ"]="pyu",["ぴょ"]="pyo",
}
local function kana_to_romaji(text)
    local function utf8_char(cp)
        if cp < 0x80 then return string.char(cp) end
        if cp < 0x800 then
            return string.char(0xC0 + math.floor(cp / 0x40), 0x80 + cp % 0x40)
        end
        if cp < 0x10000 then
            return string.char(0xE0 + math.floor(cp / 0x1000),
                0x80 + math.floor(cp / 0x40) % 0x40, 0x80 + cp % 0x40)
        end
        return string.char(0xF0 + math.floor(cp / 0x40000),
            0x80 + math.floor(cp / 0x1000) % 0x40,
            0x80 + math.floor(cp / 0x40) % 0x40, 0x80 + cp % 0x40)
    end
    local chars, result, index, geminate = utf8_chars(text), {}, 1, false
    while index <= #chars do
        local current_cp = codepoint(chars[index])
        if current_cp >= 0x30A1 and current_cp <= 0x30F6 then
            chars[index] = utf8_char(current_cp - 0x60)
        end
        local pair = chars[index] .. (chars[index + 1] or "")
        local value = kana_combo[pair]
        if value then
            table.insert(result, geminate and value:sub(1, 1) .. value or value)
            geminate = false
            index = index + 2
        else
            local char = chars[index]
            if char == "っ" then
                geminate = true
            else
                value = kana_romaji[char] or char
                table.insert(result, geminate and value:sub(1, 1) .. value or value)
                geminate = false
            end
            index = index + 1
        end
    end
    return table.concat(result)
end

local function decode_html_text(value)
    value = tostring(value or ""):gsub("<[^>]+>", "")
    value = value:gsub("&#[xX]([%x]+);", function(hex)
        return utf8_from_codepoint(tonumber(hex, 16) or 0xFFFD)
    end)
    value = value:gsub("&#(%d+);", function(number)
        return utf8_from_codepoint(tonumber(number) or 0xFFFD)
    end)
    local entities = {
        ["&amp;"] = "&", ["&lt;"] = "<", ["&gt;"] = ">",
        ["&quot;"] = '"', ["&apos;"] = "'", ["&nbsp;"] = " ",
    }
    for entity, decoded in pairs(entities) do
        value = value:gsub(entity, decoded)
    end
    return value:gsub("^%s+", ""):gsub("%s+$", "")
end

-- Read ruby supplied by the EPUB itself. These entries take precedence over
-- every dictionary result: the publisher's contextual reading is both faster
-- and more accurate for names and polyphonic kanji. Positions are expressed
-- in the same UTF-8 character coordinates used by getJapaneseTokens().
function Assist.getNativeJapaneseTokens(html, source_text)
    local tokens, search_from = {}, 1
    source_text = tostring(source_text or "")
    for ruby in tostring(html or ""):gmatch("<ruby[^>]*>(.-)</ruby>") do
        local reading_markup = ruby:match("<rt[^>]*>(.-)</rt>")
        local base_markup = ruby:match("<rb[^>]*>(.-)</rb>")
        if not base_markup then
            base_markup = ruby
                :gsub("<rt[^>]*>.-</rt>", "")
                :gsub("<rp[^>]*>.-</rp>", "")
        end
        local base = decode_html_text(base_markup)
        local reading = decode_html_text(reading_markup)
        if base ~= "" and reading ~= "" and has_cjk(base) then
            local first, last = source_text:find(base, search_from, true)
            if not first then first, last = source_text:find(base, 1, true) end
            if first then
                tokens[#tokens + 1] = {
                    start = #utf8_chars(source_text:sub(1, first - 1)) + 1,
                    length = #utf8_chars(base),
                    base = base,
                    furigana = reading,
                    romaji = kana_to_romaji(reading),
                    native = true,
                }
                search_from = last + 1
            end
        end
    end
    return tokens
end

-- A Chinese page can contain an isolated Japanese character in a title or
-- punctuation, so a single kana is not enough to switch the reading layer to
-- Japanese.  Require a small Japanese-script signal from the actual page.
function Assist.hasJapaneseScript(text)
    local kana_count = 0
    local cjk_count = 0
    for _, char in ipairs(utf8_chars(tostring(text or ""))) do
        local cp = codepoint(char)
        if is_kana(cp) then
            kana_count = kana_count + 1
        elseif is_cjk(cp) then
            cjk_count = cjk_count + 1
        end
    end
    return cjk_count > 0 and kana_count >= 2
end

local function find_sdcv()
    local data_dir = DataStorage:getDataDir()
    local candidates = {
        data_dir .. "/sdcv",
        "./sdcv",
    }
    for _, path in ipairs(candidates) do
        if lfs.attributes(path, "mode") == "file" then return path end
    end
    return candidates[1]
end

local function get_dictionary_dirs(kind)
    local data_dir = DataStorage:getDataDir() .. "/data/dict"
    local dirs = {}
    -- JMdict definitions are tiny and already contain the reading on their
    -- first line. Query it before the large Wiktionary dictionaries: asking
    -- Wiktionary for hundreds of page candidates produced megabytes of HTML
    -- and made every page wait before its overlay appeared. Missing entries
    -- still fall through to the newer dictionaries in the main directory.
    if (kind == "japanese_furigana" or kind == "japanese_romaji")
        and lfs.attributes(data_dir .. "/jmdict-ja-en", "mode") == "directory" then
        table.insert(dirs, data_dir .. "/jmdict-ja-en")
    end
    local compact_ja_dir = data_dir .. "/kotranslate-ja-en"
    if (kind == "japanese_furigana" or kind == "japanese_romaji")
        and lfs.attributes(compact_ja_dir, "mode") == "directory" then
        -- Keep the modern Japanese dictionary isolated so sdcv does not also
        -- emit the very large ja-zh/English/Chinese dictionary results.
        table.insert(dirs, compact_ja_dir)
    else
        table.insert(dirs, data_dir)
    end
    if lfs.attributes(data_dir .. "_ext", "mode") == "directory" then
        table.insert(dirs, data_dir .. "_ext")
    end
    return dirs
end

local exam_word_cache = {}

local function load_exam_words(profile)
    profile = tostring(profile or "cet4"):lower()
    if exam_word_cache[profile] then return exam_word_cache[profile] end
    local path = DataStorage:getDataDir() .. "/data/kotranslate/english/"
        .. profile .. ".tsv"
    local file = io.open(path, "rb")
    if not file then return nil end
    local words = {}
    for line in file:lines() do
        local word, gloss = line:match("^([^\t]+)\t(.+)$")
        if word and gloss then
            words[word:lower()] = gloss
        end
    end
    file:close()
    exam_word_cache[profile] = words
    return words
end

local function kana_from_definition(definition, query, ruby_only)
    -- Wiktionary entries often contain correctly paired ruby readings in
    -- usage examples even when the exported headword is malformed. Prefer a
    -- ruby sequence whose base text exactly matches the queried word.
    local ruby_items = {}
    for ruby in definition:gmatch("<ruby[^>]*>(.-)</ruby>") do
        local base, reading = ruby:match("^(.-)<rt[^>]*>(.-)</rt>")
        if base and reading then
            base = base:gsub("<[^>]+>", ""):gsub("[%(%)%[%]]", ""):gsub("%s+", "")
            reading = reading:gsub("<[^>]+>", "")
            if base ~= "" and is_kana_reading(reading) then
                table.insert(ruby_items, { base = base, reading = reading })
            end
        end
    end
    for start = 1, #ruby_items do
        local base, reading = "", ""
        for index = start, math.min(#ruby_items, start + 5) do
            base = base .. ruby_items[index].base
            reading = reading .. ruby_items[index].reading
            if base == query then return reading end
            if query and query:sub(1, #base) ~= base then break end
        end
    end

    -- For malformed synonym-index results, only an exact ruby sequence is
    -- safe.  Do not fall through to that entry's first headword reading.
    if ruby_only then return nil end

    local headword = definition:match("headword%-line(.-)</p>")
    local readings = {}
    for value in (headword or definition):gmatch("<rt[^>]*>(.-)</rt>") do
        value = value:gsub("<[^>]+>", "")
        if is_kana_reading(value) then table.insert(readings, value) end
    end
    if #readings > 0 then
        local wanted = 0
        for _, char in ipairs(utf8_chars(query or "")) do
            if is_cjk(codepoint(char)) then wanted = wanted + 1 end
        end
        wanted = math.max(1, math.min(#readings, wanted))
        return table.concat(readings, "", 1, wanted)
    end

    -- JMdict StarDict exports the reading as a plain kana line, usually
    -- immediately before the English gloss (for example: "\nかのじょ\nshe").
    -- Accept only a standalone kana line so an English gloss cannot be
    -- mistaken for a reading.
    for line in definition:gmatch("[^\r\n]+") do
        line = line:gsub("<[^>]+>", ""):gsub("&nbsp;", " ")
        line = line:gsub("^%s+", ""):gsub("%s+$", "")
        if is_kana_reading(line) then return line end
    end
    local patterns = { "【([^】]+)】", "［([^］]+)］", "%[([^%]]+)%]" }
    for _, pattern in ipairs(patterns) do
        for value in definition:gmatch(pattern) do
            if is_kana_reading(value) then return value end
        end
    end
    return nil
end

local function pick_annotation(kind, entries, query)
    for _, entry in ipairs(entries or {}) do
        -- StarDict synonym indexes may return a related entry whose headword
        -- is not the exact query (for example querying a single kanji can
        -- return an unrelated word that merely contains it).  Taking ruby
        -- from such an entry produced incorrect or partial annotations.
        local is_japanese = kind == "japanese_furigana"
            or kind == "japanese_romaji"
        local exact_japanese_entry = not is_japanese
            or tostring(entry.word or "") == tostring(query or "")
        local definition = tostring(entry.definition or "")
        local value
        if is_japanese then
            -- A malformed exported word field is acceptable only when the
            -- definition itself contains ruby whose base exactly equals the
            -- requested text.  This recovers real words without accepting
            -- unrelated synonym entries.
            value = kana_from_definition(definition, query,
                not exact_japanese_entry)
        end
        if value then return value end
    end
    return false
end

local annotation_cache = {}
local preferred_dictionary_cache = {}

function Assist.clearLookupCache()
    annotation_cache = {}
    preferred_dictionary_cache = {}
    exam_word_cache = {}
end

-- sdcv searches every dictionary in a directory unless --use-dict is given.
-- A Kindle commonly has both ja-en and ja-zh Wiktionary installed; parsing
-- both large HTML definitions for every page candidate roughly doubles CPU,
-- memory and latency. Pick one Japanese dictionary per directory, preferring
-- the more complete ja-en/JMdict data, while leaving KOReader lookup alone.
local function preferred_dictionary(dict_dir, kind)
    if kind ~= "japanese_furigana" and kind ~= "japanese_romaji" then
        return nil
    end
    if preferred_dictionary_cache[dict_dir] ~= nil then
        return preferred_dictionary_cache[dict_dir] or nil
    end
    local preferred, fallback
    local ok, iterator, state = pcall(lfs.dir, dict_dir)
    if ok and iterator then
        for filename in iterator, state do
            if filename:match("%.ifo$") then
                local file = io.open(dict_dir .. "/" .. filename, "rb")
                local content = file and file:read("*a") or ""
                if file then file:close() end
                local bookname = content:match("[\r\n]bookname=([^\r\n]+)")
                    or content:match("^bookname=([^\r\n]+)")
                if bookname and bookname ~= "" then
                    fallback = fallback or bookname
                    local lowered = (filename .. " " .. bookname):lower()
                    local wanted = lowered:find("jmdict", 1, true)
                        or lowered:find("ja-en", 1, true)
                        or lowered:find("japanese-english", 1, true)
                    if wanted then
                        preferred = bookname
                        break
                    end
                end
            end
        end
    end
    preferred_dictionary_cache[dict_dir] = preferred or fallback or false
    return preferred or fallback
end

local function lookup_sdcv(kind, words)
    local results = {}
    if #words == 0 then return results end
    local sdcv = find_sdcv()
    local pending = {}
    for _, word in ipairs(words) do
        local cache_key = kind .. "\0" .. word
        local cached = annotation_cache[cache_key]
        if cached == nil then
            table.insert(pending, word)
        elseif cached ~= false then
            results[word] = cached
        end
    end
    for _, dict_dir in ipairs(get_dictionary_dirs(kind)) do
        if #pending == 0 then break end
        if lfs.attributes(dict_dir, "mode") == "directory" then
            local args = {
                sdcv, "--utf8-input", "--utf8-output", "--json-output",
                "--non-interactive", "--exact-search",
            }
            local dictionary = preferred_dictionary(dict_dir, kind)
            if dictionary then
                table.insert(args, "--use-dict")
                table.insert(args, dictionary)
            end
            table.insert(args, "--data-dir")
            table.insert(args, dict_dir)
            table.insert(args, "--")
            for _, word in ipairs(pending) do table.insert(args, word) end
            local pipe = io.popen("(" .. shell_escape(args) .. "; echo) 2>/dev/null")
            if pipe then
                local index = 0
                local found = {}
                for line in pipe:lines() do
                    index = index + 1
                    local ok, entries = pcall(JSON.decode, line)
                    if ok and type(entries) == "table" then
                        local word = pending[index]
                        local value = pick_annotation(kind, entries, word)
                        if value and results[word] == nil then
                            results[word] = value
                            found[word] = true
                            annotation_cache[kind .. "\0" .. word] = value
                        end
                    end
                end
                pipe:close()
                local next_pending = {}
                for _, word in ipairs(pending) do
                    if not found[word] then table.insert(next_pending, word) end
                end
                pending = next_pending
            end
        end
    end
    for _, word in ipairs(pending) do
        annotation_cache[kind .. "\0" .. word] = false
    end
    return results
end

local function collect_japanese_tokens(text, lookup_batch, collected_tokens)
    local segments = {}
    local current = {}
    local function flush_run()
        if #current > 0 then
            table.insert(segments, { japanese = true, chars = current })
            current = {}
        end
    end
    for _, char in ipairs(utf8_chars(text)) do
        local cp = codepoint(char)
        if is_cjk(cp) or is_kana(cp) then
            table.insert(current, char)
        else
            flush_run()
            table.insert(segments, { japanese = false, text = char })
        end
    end
    flush_run()
    if #segments == 0 then return text end

    local candidates = {}
    local candidate_seen = {}
    local function add_candidate(value)
        if value and has_cjk(value) and not candidate_seen[value] then
            candidate_seen[value] = true
            table.insert(candidates, value)
        end
    end
    local function cjk_run_length(run, start)
        local length = 0
        while start + length <= #run and length < 6
            and is_cjk(codepoint(run[start + length])) do
            length = length + 1
        end
        return length
    end
    for _, segment in ipairs(segments) do
        if segment.japanese then
            local run = segment.chars
            -- Query plausible word boundaries only. The former implementation
            -- generated every 2..6 character substring (mostly impossible
            -- words), causing several heavyweight sdcv calls on every page.
            -- A boundary occurs at a kanji/kana transition or before the next
            -- kanji group; this retains compounds and inflected forms such as
            -- 柚木, 食べる and 申し込む with far fewer candidates.
            for start = 1, #run do
                if is_cjk(codepoint(run[start])) then
                    local compound_length = cjk_run_length(run, start)
                    if compound_length >= 2 then
                        add_candidate(table.concat(run, "", start,
                            start + compound_length - 1))
                    end
                    local max_finish = math.min(#run, start + 5)
                    for finish = start, max_finish do
                        local current_is_cjk = is_cjk(codepoint(run[finish]))
                        local next_char = run[finish + 1]
                        local next_is_cjk = next_char
                            and is_cjk(codepoint(next_char)) or false
                        local boundary = finish == max_finish
                            or not next_char
                            or (current_is_cjk and not next_is_cjk)
                            or (not current_is_cjk and next_is_cjk)
                        if boundary and finish > start then
                            add_candidate(table.concat(run, "", start, finish))
                        end
                    end
                end
            end
        end
    end

    -- Keep each sdcv invocation bounded.  Long Japanese paragraphs can have
    -- several hundred possible lexical spans; a single capped request used
    -- to leave all later lines without furigana.
    local annotations = {}
    local function lookup_in_chunks(words)
        local chunk_size = 128
        for first = 1, #words, chunk_size do
            local chunk = {}
            for index = first, math.min(#words, first + chunk_size - 1) do
                table.insert(chunk, words[index])
            end
            local found = lookup_batch("japanese_furigana", chunk) or {}
            for word, reading in pairs(found) do annotations[word] = reading end
        end
    end
    lookup_in_chunks(candidates)

    -- A continuous kanji run may contain several adjacent words.  If the
    -- complete run is not a dictionary headword, resolve it with exact
    -- 2..6-character entries before considering character readings.  This
    -- lets the word determine a polyphonic kanji's pronunciation while
    -- keeping the fast single lookup for ordinary compounds.
    local lexical_candidates, lexical_seen = {}, {}
    for _, segment in ipairs(segments) do
        if segment.japanese then
            local run = segment.chars
            local start = 1
            while start <= #run do
                if is_cjk(codepoint(run[start])) then
                    local length = cjk_run_length(run, start)
                    if length >= 2 then
                        local complete = table.concat(run, "", start,
                            start + length - 1)
                        if not annotations[complete] then
                            for offset = 0, length - 2 do
                                for size = math.min(6, length - offset), 2, -1 do
                                    local value = table.concat(run, "",
                                        start + offset,
                                        start + offset + size - 1)
                                    if not candidate_seen[value]
                                        and not lexical_seen[value] then
                                        lexical_seen[value] = true
                                        table.insert(lexical_candidates, value)
                                    end
                                end
                            end
                        end
                    end
                    start = start + math.max(1, length)
                else
                    start = start + 1
                end
            end
        end
    end
    lookup_in_chunks(lexical_candidates)

    -- Only ask for one-character readings where no longer word matched. This
    -- fills the gaps for names and uncommon kanji without multiplying the
    -- normal lookup cost for every character.
    local single_candidates, single_seen = {}, {}
    for _, segment in ipairs(segments) do
        if segment.japanese then
            local run = segment.chars
            local position = 1
            while position <= #run do
                local matched = false
                for length = math.min(6, #run - position + 1), 2, -1 do
                    local value = table.concat(run, "", position, position + length - 1)
                    if annotations[value] then matched = true; break end
                end
                local char = run[position]
                -- Always query the single-kanji fallback as well.  A longer
                -- candidate may be present but still leave one character at
                -- the edge of an inflected word without a reading.
                if has_cjk(char) and not single_seen[char] then
                    single_seen[char] = true
                    table.insert(single_candidates, char)
                end
                position = position + 1
            end
        end
    end
    lookup_in_chunks(single_candidates)
    -- JMdict is a word dictionary and legitimately has no exact entry for
    -- many isolated kanji.  KANJIDIC2 is the authoritative character-level
    -- fallback: prefer on-yomi (the useful reading inside compounds), then
    -- kun-yomi when no on-yomi exists.  This guarantees that every supported
    -- kanji gets an independent fallback instead of silently disappearing.
    for _, char in ipairs(single_candidates) do
        if not annotations[char] then
            annotations[char] = KanjiReadings[char]
        end
    end
    local text_position = 1
    for _, segment in ipairs(segments) do
        if not segment.japanese then
            text_position = text_position + 1
        else
            local run = segment.chars
            local position = 1
            while position <= #run do
                local selected_base, selected_annotation
                -- A contiguous kanji compound is one lexical unit. Force an
                -- exact compound hit to win before any mixed-form or single
                -- character fallback (恐怖 -> きょうふ, never 怖 -> ふ).
                local compound_length = cjk_run_length(run, position)
                if compound_length >= 2 then
                    local compound = table.concat(run, "", position,
                        position + compound_length - 1)
                    if annotations[compound] then
                        selected_base = compound
                        selected_annotation = annotations[compound]
                    end
                end
                if not selected_base then
                    for length = math.min(6, #run - position + 1), 1, -1 do
                        local value = table.concat(run, "", position, position + length - 1)
                        local annotation = annotations[value]
                        if annotation then
                            selected_base, selected_annotation = value, annotation
                            break
                        end
                    end
                end
                if selected_base then
                    local original_reading = selected_annotation
                    local selected_length = #utf8_chars(selected_base)
                    -- The lookup uses complete surface forms, but the visible
                    -- layer sits only above kanji the reader cannot sound out.
                    local selected_chars = utf8_chars(selected_base)
                    local run_start, run_length = nil, 0
                    local function emit_kanji_run()
                        if not run_start then return end
                        table.insert(collected_tokens, {
                            start = text_position + run_start - 1,
                            length = run_length,
                            base = table.concat(selected_chars, "", run_start,
                                run_start + run_length - 1),
                            furigana = original_reading,
                            romaji = kana_to_romaji(original_reading),
                        })
                        run_start, run_length = nil, 0
                    end
                    for index, char in ipairs(selected_chars) do
                        if is_cjk(codepoint(char)) then
                            run_start = run_start or index
                            run_length = run_length + 1
                        else
                            emit_kanji_run()
                        end
                    end
                    emit_kanji_run()
                    position = position + selected_length
                    text_position = text_position + selected_length
                else
                    position = position + 1
                    text_position = text_position + 1
                end
            end
        end
    end
end

function Assist.getJapaneseTokens(text, lookup_batch)
    local tokens = {}
    collect_japanese_tokens(tostring(text or ""), lookup_batch, tokens)
    return tokens
end

function Assist.lookupLocal(kind, words, profile)
    if kind == "english_exam" then
        local dictionary = load_exam_words(profile)
        if not dictionary then return {} end
        local results = {}
        local function candidates(word)
            local values, seen = {}, {}
            local function add(value)
                if value and value ~= "" and not seen[value] then
                    seen[value] = true
                    values[#values + 1] = value
                end
            end
            add(word)
            if word:match("ies$") then add(word:sub(1, -4) .. "y") end
            if word:match("ves$") then
                add(word:sub(1, -4) .. "f")
                add(word:sub(1, -4) .. "fe")
            end
            if word:match("es$") then add(word:sub(1, -3)) end
            if word:match("s$") and not word:match("ss$") then add(word:sub(1, -2)) end
            if word:match("ied$") then add(word:sub(1, -4) .. "y") end
            if word:match("ed$") then
                add(word:sub(1, -3))
                add(word:sub(1, -2))
            end
            if word:match("ing$") then
                local stem = word:sub(1, -4)
                add(stem)
                add(stem .. "e")
                if stem:match("([b-df-hj-np-tv-z])%1$") then add(stem:sub(1, -2)) end
            end
            if word:match("ly$") then add(word:sub(1, -3)) end
            return values
        end
        for _, word in ipairs(words or {}) do
            local original = tostring(word)
            local lowered = original:lower()
            for _, candidate in ipairs(candidates(lowered)) do
                local gloss = dictionary[candidate]
                if gloss then
                    results[original] = gloss
                    results[lowered] = gloss
                    break
                end
            end
        end
        return results
    end
    return lookup_sdcv(kind, words)
end

return Assist
