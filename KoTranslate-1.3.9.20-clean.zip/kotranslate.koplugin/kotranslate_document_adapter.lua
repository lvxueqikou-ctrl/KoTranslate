-- Unified whole-book translation adapters.  Every adapter writes only a
-- per-book overlay; source documents are never changed or repackaged.
local Epub = require("epub")
local Overlay = require("kotranslate_overlay")

local Adapter = {}

local whole_book = {
    epub = true, fb2 = true, html = true, htm = true, txt = true,
}

local function extension(path)
    return tostring(path or ""):lower():match("%.([%w]+)$") or ""
end

function Adapter.supportsWholeBook(path)
    return whole_book[extension(path)] == true
end

local function read_file(path)
    local file = io.open(path, "rb")
    if not file then return nil end
    local data = file:read("*a")
    file:close()
    if data and data:sub(1, 3) == "\239\187\191" then data = data:sub(4) end
    return data
end

local entities = {
    amp = "&", lt = "<", gt = ">", quot = '"', apos = "'", nbsp = " ",
}
local function decode_entities(text)
    text = tostring(text or "")
    text = text:gsub("&#x([%da-fA-F]+);", function(value)
        local number = tonumber(value, 16)
        return number and number < 128 and string.char(number) or " "
    end)
    text = text:gsub("&#(%d+);", function(value)
        local number = tonumber(value)
        return number and number < 128 and string.char(number) or " "
    end)
    return text:gsub("&([%a]+);", function(name) return entities[name] or " " end)
end

local function clean_text(text)
    return decode_entities(text):gsub("%s+", " "):gsub("^%s+", ""):gsub("%s+$", "")
end

local block_tags = {
    p = true, li = true, blockquote = true, subtitle = true,
    h1 = true, h2 = true, h3 = true, h4 = true, h5 = true, h6 = true,
}
local void_tags = {
    area = true, base = true, br = true, col = true, embed = true, hr = true,
    img = true, input = true, link = true, meta = true, param = true,
    source = true, track = true, wbr = true,
}

-- Small streaming markup walker. It keeps a CSS path for each paragraph,
-- which is stable for HTML and FB2 in CREngine and avoids modifying the file.
local function markup_candidates(raw)
    local candidates, stack = {}, {
        { tag = "", selector = "", counts = {}, text = nil },
    }
    local ignored = 0
    local position = 1
    while position <= #raw do
        local first, last, token = raw:find("<([^>]+)>", position)
        local plain = first and raw:sub(position, first - 1) or raw:sub(position)
        if ignored == 0 and plain ~= "" then
            for index = #stack, 1, -1 do
                if stack[index].text then
                    stack[index].text[#stack[index].text + 1] = plain
                    break
                end
            end
        end
        if not first then break end
        token = token:gsub("^%s+", ""):gsub("%s+$", "")
        local closing, tag = token:match("^(/?)([%w:_-]+)")
        tag = tag and tag:lower() or nil
        -- Some FB2 files use a namespace prefix (for example fb:p).  The
        -- reader exposes the local element name to CSS, so keep the local
        -- part for both block detection and nth-of-type paths.
        tag = tag and (tag:match("([^:]+)$") or tag) or nil
        if tag then
            if closing == "/" then
                for index = #stack, 2, -1 do
                    local node = table.remove(stack)
                    if node.text then
                        local source = clean_text(table.concat(node.text))
                        if #source >= 2 then
                            candidates[#candidates + 1] = {
                                selector = node.selector, source = source,
                            }
                        end
                    end
                    if node.tag == "script" or node.tag == "style" or node.tag == "rt" then
                        ignored = math.max(0, ignored - 1)
                    end
                    if node.tag == tag then break end
                end
            elseif token:sub(1, 1) ~= "!" and token:sub(1, 1) ~= "?" then
                local parent = stack[#stack]
                parent.counts[tag] = (parent.counts[tag] or 0) + 1
                local part = tag .. ":nth-of-type(" .. parent.counts[tag] .. ")"
                local selector = parent.selector == "" and part
                    or (parent.selector .. " > " .. part)
                local node = {
                    tag = tag, selector = selector, counts = {},
                    text = block_tags[tag] and {} or nil,
                }
                if tag == "script" or tag == "style" or tag == "rt" then
                    ignored = ignored + 1
                end
                if not void_tags[tag] and not token:match("/%s*$") then
                    stack[#stack + 1] = node
                end
            end
        end
        position = last + 1
    end
    return candidates
end

local function normalize_fb2_candidates(candidates)
    -- The XML document element is not addressable in CREngine's reflow CSS
    -- tree.  A path beginning with FictionBook therefore never matches,
    -- while body/section/p paths do.  Strip only that FB2 wrapper and keep
    -- all paragraph/section positions intact.
    for _, candidate in ipairs(candidates) do
        candidate.selector = candidate.selector:gsub(
            "^fictionbook:nth%-of%-type%(%d+%)%s*>%s*", "")
    end
    return candidates
end

local function utf8_slice(text, first, count)
    local positions, position, length = {}, 1, #text
    while position <= length do
        positions[#positions + 1] = position
        local byte = text:byte(position)
        local width = byte < 0x80 and 1
            or (byte < 0xE0 and 2 or (byte < 0xF0 and 3 or 4))
        position = math.min(length + 1, position + width)
    end
    local start_at = positions[first]
    if not start_at then return "" end
    local finish_at = positions[first + count] or (length + 1)
    return text:sub(start_at, finish_at - 1)
end

local function css_attribute_string(text)
    return '"' .. tostring(text):gsub("\\", "\\\\")
        :gsub('"', '\\"'):gsub("\r", " "):gsub("\n", " ") .. '"'
end

-- CREngine may remove indentation, merge wrapped TXT lines, and turn detected
-- headings into sections.  A starts-with selector consequently misses valid
-- paragraphs.  Pick a reasonably long, preferably unique fragment from each
-- paragraph and match it anywhere in the rendered paragraph instead.  This is
-- independent of a book's line wrapping and paragraph numbering.
local function text_candidates(raw)
    raw = raw:gsub("\r\n", "\n"):gsub("\r", "\n")
    local candidates = {}
    local function add(text)
        text = clean_text(text)
        if text == "" then return end
        candidates[#candidates + 1] = { source = text }
    end
    if raw:find("\n%s*\n") then
        for paragraph in (raw .. "\n\n"):gmatch("(.-)\n%s*\n") do
            add(paragraph)
        end
    else
        for line in (raw .. "\n"):gmatch("([^\n]*)\n") do
            add(line)
        end
    end
    for index, candidate in ipairs(candidates) do
        local anchor, unique_fallback
        -- Prefer an internal fragment without ASCII punctuation. In
        -- particular, commas and quotes in a CSS text attribute are handled
        -- inconsistently by older CRE builds. Trying internal positions also
        -- survives indentation removal and heading detection. Every accepted
        -- fragment is checked against the whole book before it is used.
        for _, count in ipairs({ 24, 18, 12 }) do
            for _, start_at in ipairs({ 1, 7, 13, 19, 25, 31, 37, 49, 61, 73 }) do
                local fragment = utf8_slice(candidate.source, start_at, count)
                if fragment ~= "" then
                    local occurrences = 0
                    for _, other in ipairs(candidates) do
                        if other.source:find(fragment, 1, true) then
                            occurrences = occurrences + 1
                            if occurrences > 1 then break end
                        end
                    end
                    if occurrences == 1 then
                        unique_fallback = unique_fallback or fragment
                        if not fragment:find("[%c%p]") then
                            anchor = fragment
                            break
                        end
                    end
                end
            end
            if anchor then break end
        end
        anchor = anchor or unique_fallback
        if anchor then
            candidate.selector = "p[_*=" .. css_attribute_string(anchor) .. "]"
        else
            -- A short heading may also occur inside a longer paragraph (for
            -- example a book title mentioned in a biography).  A contains
            -- selector would then override the longer paragraph's ::after
            -- content.  Match the complete paragraph in this fallback case.
            candidate.selector = "p[_=" .. css_attribute_string(candidate.source) .. "]"
        end
    end
    return candidates
end

local function write_progress(path, current, total, translated, failed)
    if not path then return end
    local file = io.open(path, "w")
    if file then
        file:write(string.format("%d|%d|%d|%d|1|1", current, total,
            translated, failed))
        file:close()
    end
end

local function wait_for_control(path)
    if not path then return true end
    while true do
        local file = io.open(path, "rb")
        local state = file and file:read("*l") or nil
        if file then file:close() end
        if state == "abort" then return false end
        if state ~= "pause" then return true end
        os.execute("sleep 1")
    end
end

local function translate_reflow(options)
    local raw = read_file(options.book_path)
    if not raw then return nil, "无法读取文档" end
    local ext = extension(options.book_path)
    local candidates
    if ext == "txt" then
        candidates = text_candidates(raw)
    else
        candidates = markup_candidates(raw)
    end
    if ext == "fb2" then
        candidates = normalize_fb2_candidates(candidates)
    end
    if #candidates == 0 then return nil, "没有找到可翻译的段落" end
    os.execute("mkdir -p " .. string.format("%q", options.output_dir))
    local output = options.output_dir .. "/overlay.json"
    local old, old_by_selector = Overlay.load(output), {}
    if old and old.book_path == options.book_path
        and old.source_lang == options.source_lang
        and old.target_lang == options.target_lang then
        for _, entry in ipairs(old.entries or {}) do
            old_by_selector[entry.selector] = entry
        end
    end
    local entries, translated, failed = {}, 0, 0
    write_progress(options.progress_path, 0, #candidates, 0, 0)
    -- Use the same provider batch path as EPUB.  The previous reflow path
    -- translated every TXT/FB2 paragraph with a separate request, which was
    -- needlessly slow on older readers.
    local batch_size = 12
    for batch_start = 1, #candidates, batch_size do
        if not wait_for_control(options.control_path) then
            Overlay.save(output, {
                version = 3, complete = false,
                book_path = options.book_path,
                source_lang = options.source_lang,
                target_lang = options.target_lang,
                entries = entries,
            })
            return { aborted = true, output = output,
                translated = translated, failed = failed }
        end
        local batch_end = math.min(#candidates, batch_start + batch_size - 1)
        local values, request_texts, request_positions = {}, {}, {}
        for index = batch_start, batch_end do
            local candidate = candidates[index]
            local previous = old_by_selector[candidate.selector]
            if previous and previous.source == candidate.source
                and previous.translation and previous.translation ~= "" then
                values[index] = previous.translation
            else
                request_positions[#request_positions + 1] = index
                request_texts[#request_texts + 1] = candidate.source
            end
        end
        if #request_texts > 0 then
            local results
            if options.translate_batch then
                results = options.translate_batch(request_texts)
            end
            if type(results) ~= "table" then results = {} end
            for offset, index in ipairs(request_positions) do
                values[index] = results[offset]
            end
        end
        for index = batch_start, batch_end do
            local candidate, value = candidates[index], values[index]
            if value and value ~= "" then
                translated = translated + 1
                entries[#entries + 1] = {
                    selector = candidate.selector, source = candidate.source,
                    translation = value,
                }
            else
                failed = failed + 1
            end
        end
        local current = batch_end
        if current % 8 == 0 or current == #candidates then
            Overlay.save(output, {
                version = 3, complete = current == #candidates and failed == 0,
                book_path = options.book_path,
                source_lang = options.source_lang,
                target_lang = options.target_lang,
                entries = entries,
            })
            write_progress(options.progress_path, current, #candidates, translated, failed)
        end
    end
    if options.progress_path then os.remove(options.progress_path) end
    return { output = output, translated = translated, failed = failed }
end

function Adapter.translate(options)
    local ext = extension(options.book_path)
    if ext == "epub" then
        return Epub:translate_overlay(options.book_path, options.fragment,
            options.target_lang, options.source_lang, options.translate,
            options.all_chapters, options.progress_path, options.translate_batch,
            options.output_dir, nil, options.control_path)
    end
    if whole_book[ext] then return translate_reflow(options) end
    return nil, "该格式暂不支持整书正文内译文"
end

return Adapter
