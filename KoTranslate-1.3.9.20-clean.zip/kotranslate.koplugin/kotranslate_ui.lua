local Device = require("device")
local InfoMessage = require("ui/widget/infomessage")
local TextViewer = require("ui/widget/textviewer")
local UIManager = require("ui/uimanager")
local Screen = Device.screen
local _ = require("gettext")

local TranslationUI = {}

function TranslationUI.showTranslation(source_text, result, source_lang, target_lang, from_highlight, index)
    local Languages = require("kotranslate_languages")
    local source_name = Languages.getNameByCode(source_lang)
    local target_name = Languages.getNameByCode(target_lang)

    local provider_label = ""
    if result.provider then
        provider_label = " [" .. result.provider .. "]"
    elseif result.model_type then
        provider_label = " [" .. result.model_type .. "]"
    end
    if result.cached then
        provider_label = provider_label .. " [Cached]"
    end

    local title = string.format("%s → %s%s", source_name, target_name, provider_label)

    local translated_text = result.translated_text
    local text_all = string.format(
        "● %s\n\n▣ %s",
        translated_text,
        source_text
    )

    local textviewer, buttons_table, close_callback
    local height = math.floor(Screen:getHeight() * 0.7)
    buttons_table = {}

    -- If called from highlight, add "Save to note" buttons (like built-in translator)
    if from_highlight then
        local ui = require("apps/reader/readerui").instance
        if ui and ui.highlight then
            table.insert(buttons_table, {
                {
                    text = _("Save translation to note"),
                    callback = function()
                        UIManager:close(textviewer)
                        if ui.highlight.highlight_dialog then
                            UIManager:close(ui.highlight.highlight_dialog)
                            ui.highlight.highlight_dialog = nil
                        end
                        if index then
                            ui.highlight:editNote(index, false, translated_text)
                        else
                            ui.highlight:addNote(translated_text)
                        end
                    end,
                },
            })
            close_callback = function()
                if not ui.highlight.highlight_dialog then
                    ui.highlight:clear()
                end
            end
        end
    end

    -- Copy buttons
    if Device:hasClipboard() then
        table.insert(buttons_table, {
            {
                text = _("Copy translation"),
                callback = function()
                    Device.input.setClipboardText(translated_text)
                end,
            },
            {
                text = _("Copy all"),
                callback = function()
                    Device.input.setClipboardText(text_all)
                end,
            },
        })
    end

    textviewer = TextViewer:new{
        title = title,
        text = text_all,
        text_type = "lookup",
        height = height,
        add_default_buttons = true,
        buttons_table = buttons_table,
        close_callback = close_callback,
    }
    
    -- Close any existing highlight dialog first to prevent screen corruption
    if from_highlight then
        local ui = require("apps/reader/readerui").instance
        if ui and ui.highlight and ui.highlight.highlight_dialog then
            UIManager:close(ui.highlight.highlight_dialog)
            ui.highlight.highlight_dialog = nil
        end
    end
    
    UIManager:show(textviewer)
    -- Force full screen refresh to prevent display corruption
    UIManager:setDirty("all", "full")
end

function TranslationUI.showError(message)
    UIManager:show(InfoMessage:new{
        text = message,
        timeout = 5,
    })
end

function TranslationUI.showInfo(message, timeout)
    UIManager:show(InfoMessage:new{
        text = message,
        timeout = timeout or 3,
    })
end

return TranslationUI
