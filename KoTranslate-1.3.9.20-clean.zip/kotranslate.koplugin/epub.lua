-- Read-only EPUB adapter. It maps source paragraphs to generated overlay CSS;
-- the archive itself is never written or repacked.

local Epub = {}
local Overlay = require("kotranslate_overlay")

local function shell_quote(value)
    return "'" .. tostring(value):gsub("'", "'\\''") .. "'"
end

local function command_ok(command)
    local result = os.execute(command)
    return result == true or result == 0
end

local function read_file(path)
    local file = io.open(path, "rb")
    if not file then return nil end
    local data = file:read("*a")
    file:close()
    return data
end

local function attr(tag, name)
    local escaped_name = name:gsub("([%^%$%(%)%%%.%[%]%*%+%-%?])", "%%%1")
    local pattern = escaped_name .. "%s*=%s*[\"']([^\"']+)[\"']"
    return tag:match(pattern)
end

local function url_decode(value)
    return (value:gsub("%%(%x%x)", function(hex)
        return string.char(tonumber(hex, 16))
    end))
end

local function normalize_path(path)
    local parts = {}
    for part in path:gmatch("[^/]+") do
        if part == ".." then
            table.remove(parts)
        elseif part ~= "." and part ~= "" then
            table.insert(parts, part)
        end
    end
    return table.concat(parts, "/")
end

local function dirname(path)
    return path:match("^(.*)/[^/]+$") or ""
end

local function html_to_text(html)
    -- Ruby readings are metadata for the base Japanese text, not additional
    -- words to send to the translator.  Keeping <rt> content used to turn e.g.
    -- 素人 into "素人 しろうと", which confused sentence translation and
    -- produced the apparently missing/broken clauses seen in the reader.
    html = html:gsub("<[rR][tT][^>]*>.-</[rR][tT]%s*>", "")
    html = html:gsub("<br%s*/?>", "\n")
    html = html:gsub("<[^>]+>", " ")
    html = html:gsub("&nbsp;", " ")
        :gsub("&amp;", "&")
        :gsub("&lt;", "<")
        :gsub("&gt;", ">")
        :gsub("&quot;", "\"")
        :gsub("&#39;", "'")
    return html:gsub("%s+", " "):gsub("^%s+", ""):gsub("%s+$", "")
end

local function looks_translatable(text)
    if not text or #text < 2 then return false end
    if not text:match("[%a\128-\255]") then return false end
    return true
end

local function write_progress(path, current, total, translated, failed, chapter, chapters)
    if not path then return end
    local file = io.open(path, "w")
    if not file then return end
    file:write(string.format("%d|%d|%d|%d|%d|%d\n",
        current or 0, total or 0, translated or 0, failed or 0,
        chapter or 0, chapters or 0))
    file:close()
end

function Epub:resolve(book_path, work_dir, fragment)
    local container = read_file(work_dir .. "/META-INF/container.xml")
    if not container then return nil, "找不到 META-INF/container.xml" end
    local opf_path
    -- EPUBs may use a namespace prefix (for example container:rootfile),
    -- and some put rootfiles/rootfile on separate formatting lines.
    for rootfile_tag in container:gmatch("<[^>]*rootfile[^>]*>") do
        opf_path = attr(rootfile_tag, "full-path")
        if opf_path then break end
    end
    if not opf_path then return nil, "找不到 OPF 路径" end
    opf_path = normalize_path(url_decode(opf_path))
    local opf = read_file(work_dir .. "/" .. opf_path)
    if not opf then return nil, "找不到 OPF 文件" end

    local manifest = {}
    for item in opf:gmatch("<[%w_%-]*:?item[^>]*>") do
        local id = attr(item, "id")
        local href = attr(item, "href")
        if id and href then
            manifest[id] = normalize_path(dirname(opf_path) .. "/" .. url_decode(href:gsub("#.*$", "")))
        end
    end

    local spine = {}
    for itemref in opf:gmatch("<[%w_%-]*:?itemref[^>]*>") do
        local idref = attr(itemref, "idref")
        if idref and manifest[idref] then
            table.insert(spine, manifest[idref])
        end
    end

    local index = tonumber(tostring(fragment or ""):match("DocFragment%[(%d+)%]")) or 1
    local relative = spine[index] or spine[1]
    if not relative then return nil, "找不到可读取的 spine 项" end
    return {
        relative = relative,
        absolute = work_dir .. "/" .. relative,
        index = index,
        spine_count = #spine,
        spine = spine,
    }
end

local overlay_target_tags = {
    p = true, h1 = true, h2 = true, h3 = true, h4 = true, h5 = true, h6 = true,
    figcaption = true, dt = true, dd = true,
}

local void_tags = {
    area = true, base = true, br = true, col = true, embed = true, hr = true,
    img = true, input = true, link = true, meta = true, param = true,
    source = true, track = true, wbr = true,
}

local function css_attribute(value)
    return tostring(value or ""):gsub("\\", "\\\\"):gsub('"', '\\"')
end

-- Build selectors from the original XHTML tree.  These selectors address
-- CREngine's internal DocFragment nodes, so generated text is laid out in the
-- open source EPUB while the archive itself stays byte-for-byte untouched.
local function collect_overlay_candidates(document, relative, fragment_index, div_fallback)
    local targets = div_fallback and { div = true } or overlay_target_tags
    local root = { counts = {}, in_body = false, path = "", xpath = "" }
    local stack = { root }
    local candidates = {}
    local position = 1
    while true do
        local tag_start, tag_end = document:find("<[^>]*>", position)
        if not tag_start then break end
        local raw = document:sub(tag_start, tag_end)
        position = tag_end + 1
        if not raw:match("^<%s*[!?]") then
            local closing = raw:match("^<%s*/") ~= nil
            local name = raw:match("^<%s*/?%s*([%w_:%-]+)")
            if name then
                name = name:lower():gsub("^.-:", "")
                if closing then
                    local found
                    for index = #stack, 2, -1 do
                        if stack[index].name == name then found = index; break end
                    end
                    if found then
                        local node = stack[found]
                        if node.target and node.inner_start then
                            local inner = document:sub(node.inner_start, tag_start - 1)
                            local source = html_to_text(inner)
                            if looks_translatable(source) then
                                table.insert(candidates, {
                                    source = source,
                                    selector = 'DocFragment[Source="' .. css_attribute(relative)
                                        .. '"] > body' .. node.path,
                                    xpointer = "/body/DocFragment"
                                        .. (fragment_index > 1
                                            and ("[" .. tostring(fragment_index) .. "]") or "")
                                        .. "/body" .. node.xpath,
                                })
                            end
                        end
                        for index = #stack, found, -1 do table.remove(stack) end
                    end
                else
                    local parent = stack[#stack]
                    parent.counts[name] = (parent.counts[name] or 0) + 1
                    local in_body = parent.in_body or name == "body"
                    local path = parent.path
                    local xpath = parent.xpath
                    if name == "body" then
                        path = ""
                        xpath = ""
                    elseif in_body then
                        path = path .. " > " .. name .. ":nth-of-type("
                            .. tostring(parent.counts[name]) .. ")"
                        xpath = xpath .. "/" .. name
                            .. (parent.counts[name] > 1
                                and ("[" .. tostring(parent.counts[name]) .. "]") or "")
                    end
                    local node = {
                        name = name,
                        counts = {},
                        in_body = in_body,
                        path = path,
                        xpath = xpath,
                        inner_start = tag_end + 1,
                        target = in_body and targets[name] == true,
                    }
                    local self_closing = raw:match("/%s*>$") ~= nil or void_tags[name]
                    if not self_closing then table.insert(stack, node) end
                end
            end
        end
    end
    return candidates
end

local function assist_lines(markup)
    markup = tostring(markup or "")
    local romaji = markup:match('<p class="kotranslate%-ja%-romaji%-line">(.-)</p>')
    local furigana = markup:match('<p class="kotranslate%-ja%-furigana%-line">(.-)</p>')
    if romaji or furigana then
        return html_to_text(furigana or ""), html_to_text(romaji or ""), nil
    end
    local english = {}
    for value in markup:gmatch("<rt[^>]*>(.-)</rt>") do
        value = html_to_text(value)
        if value ~= "" then table.insert(english, value) end
    end
    return nil, nil, #english > 0 and table.concat(english, " ") or nil
end

function Epub:translate_overlay(book_path, fragment, target_lang, source_lang,
        translate, all_chapters, progress_path, translate_batch, output_dir, assist,
        control_path)
    if not book_path:lower():match("%.epub$") then
        return nil, "整书翻译目前仅支持 EPUB"
    end
    local data_dir = require("datastorage"):getDataDir()
    local nonce = tostring(os.time()) .. "_" .. tostring(math.random(100000, 999999))
    local work_dir = data_dir .. "/cache/kotranslate/overlay_" .. nonce
    if not command_ok("mkdir -p " .. shell_quote(work_dir)) then
        return nil, "无法创建临时目录"
    end
    local function cleanup()
        os.execute("rm -rf " .. shell_quote(work_dir))
        if progress_path then os.remove(progress_path) end
    end
    if not command_ok("unzip -qq -o " .. shell_quote(book_path)
        .. " -d " .. shell_quote(work_dir)) then
        cleanup()
        return nil, "无法解包 EPUB（可能受 DRM 保护）"
    end
    local chapter, err = self:resolve(book_path, work_dir, fragment)
    if not chapter then cleanup(); return nil, err end
    local chapters = {}
    if all_chapters then
        for index, relative in ipairs(chapter.spine) do
            table.insert(chapters, { index = index, relative = relative,
                absolute = work_dir .. "/" .. relative })
        end
    else
        table.insert(chapters, chapter)
    end

    local chapter_candidates = {}
    local total = 0
    for _, current in ipairs(chapters) do
        local document = read_file(current.absolute)
        local candidates = document and collect_overlay_candidates(document,
            current.relative, current.index, false) or {}
        if #candidates == 0 and document then
            candidates = collect_overlay_candidates(document, current.relative,
                current.index, true)
        end
        chapter_candidates[current.index] = candidates
        total = total + #candidates
    end
    if total == 0 then cleanup(); return nil, "没有找到可翻译的段落" end

    if not command_ok("mkdir -p " .. shell_quote(output_dir)) then
        cleanup(); return nil, "无法创建本书翻译缓存目录"
    end
    local output = output_dir .. "/overlay.json"
    local entries, entry_index = {}, {}
    -- A killed subprocess or closing the book may interrupt a run.  Keep the
    -- batches already completed and merge into them on the next run.
    local previous = Overlay.load(output)
    if previous
        and previous.book_path == book_path
        and previous.source_lang == source_lang
        and previous.target_lang == target_lang then
        for _, entry in ipairs(previous.entries or {}) do
            if entry.selector and entry.translation then
                entries[#entries + 1] = entry
                entry_index[entry.selector] = #entries
            end
        end
    end
    local function save_checkpoint(complete)
        return Overlay.save(output, {
            version = 2, complete = complete == true,
            book_path = book_path, source_lang = source_lang,
            target_lang = target_lang, entries = entries,
        })
    end
    local function wait_for_control()
        if not control_path then return true end
        while true do
            local file = io.open(control_path, "rb")
            local state = file and file:read("*l") or nil
            if file then file:close() end
            if state == "abort" then return false end
            if state ~= "pause" then return true end
            os.execute("sleep 1")
        end
    end
    local processed, translated_count, failed_count = 0, 0, 0
    local first_error
    write_progress(progress_path, 0, total, 0, 0, 0, #chapters)
    for _, current in ipairs(chapters) do
        local candidates = chapter_candidates[current.index] or {}
        local batch_size = 48
        for first = 1, #candidates, batch_size do
            if not wait_for_control() then
                save_checkpoint(false)
                cleanup()
                return { aborted = true, output = output,
                    translated = translated_count, failed = failed_count }
            end
            local last = math.min(first + batch_size - 1, #candidates)
            local sources, translations = {}, {}
            local pending_sources, pending_offsets = {}, {}
            for index = first, last do
                local candidate = candidates[index]
                local offset = #sources + 1
                sources[offset] = candidate.source
                local old_index = entry_index[candidate.selector]
                local old = old_index and entries[old_index]
                if old and old.source == candidate.source and old.translation ~= "" then
                    translations[offset] = old.translation
                else
                    pending_sources[#pending_sources + 1] = candidate.source
                    pending_offsets[#pending_offsets + 1] = offset
                end
            end
            if translate_batch and #pending_sources > 0 then
                local ok, values, batch_err = pcall(translate_batch, pending_sources)
                if ok and values then
                    for index = 1, #pending_offsets do
                        translations[pending_offsets[index]] = values[index]
                    end
                else first_error = first_error or ((not ok and values) or batch_err) end
            end
            for offset, source in ipairs(sources) do
                local candidate = candidates[first + offset - 1]
                local translated = translations[offset]
                if not translated or translated == "" then
                    local ok, value, single_err = pcall(translate, source)
                    if ok then translated = value else first_error = first_error or value end
                    first_error = first_error or single_err
                end
                processed = processed + 1
                if translated and translated ~= "" then
                    local entry = { selector = candidate.selector,
                        xpointer = candidate.xpointer, source = source,
                        translation = translated }
                    if assist then
                        local ok, markup = pcall(assist, source, source)
                        if ok and markup then
                            if type(markup) == "table" then
                                entry.japanese_tokens = markup.japanese_tokens
                            else
                                entry.furigana, entry.romaji, entry.english = assist_lines(markup)
                            end
                        end
                    end
                    local existing = entry_index[entry.selector]
                    if existing then
                        entries[existing] = entry
                    else
                        entries[#entries + 1] = entry
                        entry_index[entry.selector] = #entries
                    end
                    translated_count = translated_count + 1
                else
                    failed_count = failed_count + 1
                end
                write_progress(progress_path, processed, total, translated_count,
                    failed_count, current.index, #chapters)
            end
            -- Atomic JSON replacement after every network batch provides a
            -- real restart point even when KOReader or the book closes.
            save_checkpoint(false)
        end
    end
    if translated_count == 0 then
        cleanup()
        return nil, type(first_error) == "table" and first_error.message
            or tostring(first_error or "翻译服务没有返回译文")
    end
    local saved = save_checkpoint(failed_count == 0)
    cleanup()
    if not saved then return nil, "无法保存本书翻译缓存" end
    return {
        output = output,
        overlay = true,
        chapters = #chapters,
        translated = translated_count,
        failed = failed_count,
    }
end

return Epub
