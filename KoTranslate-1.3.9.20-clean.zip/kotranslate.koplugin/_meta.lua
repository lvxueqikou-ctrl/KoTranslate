local _ = require("gettext")
return {
    name = "kotranslate",
    fullname = _("KoTranslate"),
    description = _([[Lightweight translation and reading-assistance plugin using Google Free and Microsoft Edge Free.]]),
    version = "1.3.9.20",
}
