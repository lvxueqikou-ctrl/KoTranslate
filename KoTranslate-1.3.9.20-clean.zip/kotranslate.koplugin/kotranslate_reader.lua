-- Reader-facing translation, EPUB mapping, and styling operations.
-- Menu, persistence, and provider implementations live in separate modules.
local Device = require("device")
local InfoMessage = require("ui/widget/infomessage")
local InputDialog = require("ui/widget/inputdialog")
local UIManager = require("ui/uimanager")
local Screen = Device.screen
local logger = require("logger")
local _ = require("gettext")
local Event = require("ui/event")
local Trapper = require("ui/trapper")
local DataStorage = require("datastorage")
local Providers = require("kotranslate_providers")
local TranslationUI = require("kotranslate_ui")
local Assist = require("kotranslate_assist")
local Overlay = require("kotranslate_overlay")
local DocumentAdapter = require("kotranslate_document_adapter")
local Font = require("ui/font")
local RenderText = require("ui/rendertext")
local Blitbuffer = require("ffi/blitbuffer")

local Reader = {}

local function stable_path_hash(value)
    local hash = 7
    for index = 1, #value do
        hash = (hash * 131 + value:byte(index)) % 2147483647
    end
    return string.format("%08x", hash)
end

function Reader.attach(plugin)
    local kotranslate = plugin
local function trim_text(text)
    return (text:gsub("^%s+", ""):gsub("%s+$", ""))
end

function kotranslate:splitTranslationText(text, limit)
    if #text <= limit then return { text } end
    local chunks = {}
    local rest = text
    while #rest > limit do
        local cut = limit
        local search_from = math.max(1, limit - 160)
        -- Prefer whitespace or sentence punctuation near the limit, so that
        -- English words and sentences are not cut in the middle.
        for i = limit, search_from, -1 do
            local character = rest:sub(i, i)
            if character:match("[%s%.,;:%?!]" ) then
                cut = i
                break
            end
        end
        -- If there is no whitespace (for example, a CJK paragraph), avoid
        -- splitting in the middle of a UTF-8 byte sequence.
        while cut > 1 do
            local byte = rest:byte(cut)
            if not byte or byte < 128 or byte > 191 then break end
            cut = cut - 1
        end
        local part = trim_text(rest:sub(1, cut))
        if part == "" then
            cut = limit
            part = rest:sub(1, cut)
        end
        table.insert(chunks, part)
        rest = trim_text(rest:sub(cut + 1))
    end
    if rest ~= "" then table.insert(chunks, rest) end
    return chunks
end

-- Whole-book translation uses KoTranslate's provider registry directly and
-- stores the result in a non-destructive per-book overlay cache.
function kotranslate:translateDocumentText(text)
    local mode = self:getMode()
    local source_lang = self:getSourceLang()
    local target_lang = self:getTargetLang()
    local result, err

    if self:isCacheEnabled() then
        local cached = self.cache:lookupForBook(self._active_translation_book,
            source_lang, target_lang, text)
        if cached and cached.translated_text
            and not cached.translated_text:match("MYMEMORY%s+WARNING") then
            return cached.translated_text, nil
        end
    end

    if mode == "default" then
        return nil, { message = "请先选择 KoTranslate 翻译服务" }
    end

    -- Keep long paragraphs below the selected provider's request limit.  The
    -- recursive calls use the same v19 one-paragraph request path, while the
    -- final result remains one continuous translation in the EPUB.
    local limit = self:getTranslationChunkLimit()
    if #text > limit then
        local translated_parts = {}
        for _, chunk in ipairs(self:splitTranslationText(text, limit)) do
            local translated, chunk_err = self:translateDocumentText(chunk)
            if not translated then return nil, chunk_err end
            table.insert(translated_parts, translated)
        end
        local combined = table.concat(translated_parts, " ")
        if self:isCacheEnabled() then
            self.cache:storeForBook(self._active_translation_book, source_lang,
                target_lang, text, combined, mode)
        end
        return combined, nil
    end

    -- Keep the v19 request path: one paragraph, one provider request.
    -- The newer chunk/batch path was slower on-device and could turn one
    -- failed request into a failed EPUB generation.
    result, err = Providers.translate(mode, text, source_lang, target_lang)

    if result and result.translated_text and result.translated_text ~= ""
        and not result.translated_text:match("MYMEMORY%s+WARNING") then
        if self:isCacheEnabled() then
            self.cache:storeForBook(self._active_translation_book, source_lang,
                target_lang, text, result.translated_text, result.provider or mode)
        end
        return result.translated_text, nil
    end
    return nil, err or { message = "翻译服务没有返回译文" }
end

function kotranslate:isWholeBookTranslationSupported()
    local path = self.ui and self.ui.document and self.ui.document.file
    return DocumentAdapter.supportsWholeBook(path)
end

function kotranslate:getBookCacheDirectory(book_path)
    local data_dir = require("datastorage"):getDataDir()
    return data_dir .. "/cache/kotranslate/books/"
        .. stable_path_hash(book_path .. "|" .. self:getTargetLang())
end

function kotranslate:getTranslationOverlayPath(book_path)
    if not book_path then return nil end
    return self:getBookCacheDirectory(book_path) .. "/overlay.json"
end

function kotranslate:hasTranslationOverlay(book_path)
    local path = self:getTranslationOverlayPath(book_path)
    return path and Overlay.exists(path) or false
end

function kotranslate:toggleTranslationVisible()
    local current = self.ui and self.ui.document and self.ui.document.file
    if not current or not self:hasTranslationOverlay(current) then return end
    self:saveSetting("translation_visible",
        self:getSetting("translation_visible", true) ~= true)
    self:applyAssistRuntimeStyle()
end

function kotranslate:removeTranslationDataForBook(book_path)
    if not book_path then return 0 end
    local source_for_overlay = book_path
    local removed = 0
    local overlay_path = self:getTranslationOverlayPath(source_for_overlay)
    local overlay = overlay_path and Overlay.load(overlay_path) or nil
    local cache_dir = self:getBookCacheDirectory(source_for_overlay)
    local books_root = DataStorage:getDataDir() .. "/cache/kotranslate/books/"
    if cache_dir:sub(1, #books_root) == books_root and #cache_dir > #books_root then
        if overlay then removed = removed + 1 end
        os.execute("rm -rf " .. string.format("%q", cache_dir))
    end
    return removed, source_for_overlay, overlay
end

function kotranslate:getCurrentFragment()
    local document = self.ui.document
    if not document.getXPointer then return nil end
    local ok, xpointer = pcall(function() return document:getXPointer() end)
    return ok and xpointer or nil
end

function kotranslate:translateBook(all_chapters)
    if not self:isWholeBookTranslationSupported() then return end
    local book_path = self.ui.document.file
    local fragment = all_chapters and nil or self:getCurrentFragment()
    self:enqueueTranslation(book_path, all_chapters, fragment)
end

function kotranslate:_runTranslation(item)
    local book_path = item.book_path
    local all_chapters = item.all_chapters
    self._active_translation_book = book_path
    self._assist_language = nil
    local fragment = item.fragment
    local data_dir = DataStorage:getDataDir()
    local progress_path = data_dir .. "/cache/kotranslate/progress_"
        .. tostring(os.time()) .. "_" .. tostring(math.random(10000, 99999)) .. ".txt"
    local control_path = progress_path .. ".control"
    os.execute("mkdir -p " .. string.format("%q", data_dir .. "/cache/kotranslate"))
    self._translation_progress = {
        active = true,
        all_chapters = all_chapters,
        book_path = book_path,
        item = item,
        path = progress_path,
        control_path = control_path,
    }
    item.progress_path = progress_path
    item.control_path = control_path
    os.remove(control_path)
    self:saveTranslationQueue()

    UIManager:scheduleIn(0.1, function()
        -- Show the initial progress card while the job belongs to the book
        -- currently on screen.  Dismissing this card only hides it; the
        -- worker continues and the queue remains the durable status view.
        local progress_dialog
        local progress_active = true
        if self.ui and self.ui.document and self.ui.document.file == book_path then
            progress_dialog = InfoMessage:new{
                text = all_chapters and "正在翻译整本书…\n准备中…\n点按此处可收起，任务会继续。"
                    or "正在翻译当前章节…\n准备中…\n点按此处可收起，任务会继续。",
                width = math.floor(Screen:getWidth() * 0.78),
                show_icon = false,
                dismissable = true,
            }
            self._translation_progress.dialog = progress_dialog
            local previous_close = progress_dialog.onCloseWidget
            function progress_dialog:onCloseWidget()
                self._kotranslate_hidden = true
                if previous_close then return previous_close(self) end
            end
            UIManager:show(progress_dialog)
        end

        local function close_progress()
            progress_active = false
            if progress_dialog then pcall(function() UIManager:close(progress_dialog) end) end
        end

        local function update_progress()
            if not progress_active or not progress_dialog
                or progress_dialog._kotranslate_hidden then return end
            local file = io.open(progress_path, "r")
            local line = file and file:read("*l") or nil
            if file then file:close() end
            if line then
                local current, total, translated, failed, chapter, chapters = line:match(
                    "^(%d+)|(%d+)|(%d+)|(%d+)|(%d+)|(%d+)$")
                current, total = tonumber(current), tonumber(total)
                if current and total then
                    item.current, item.total = current, total
                    item.translated, item.failed = tonumber(translated) or 0,
                        tonumber(failed) or 0
                    local percent = total > 0 and math.floor(current * 100 / total + 0.5) or 0
                    local filled = math.floor(percent / 5 + 0.5)
                    progress_dialog.text = string.format(
                        "%s\n[%s%s] %d%%\n段落：%d/%d\n已翻译：%d    失败：%d\n章节：%d/%d\n点按此处可收起，任务会继续。",
                        all_chapters and "正在翻译整本书…" or "正在翻译当前章节…",
                        string.rep("█", filled), string.rep("░", 20 - filled), percent,
                        current, total, item.translated, item.failed,
                        tonumber(chapter) or 0, tonumber(chapters) or 0)
                    pcall(function()
                        progress_dialog:init()
                        UIManager:setDirty(progress_dialog, function()
                            return "ui", progress_dialog.movable.dimen
                        end)
                    end)
                end
            end
            UIManager:scheduleIn(0.5, update_progress)
        end
        UIManager:scheduleIn(0.5, update_progress)

        Trapper:wrap(function()
            -- Passing a table avoids Trapper creating its default full-screen
            -- dismiss widget. Page touches remain usable and cannot cancel the
            -- background task.
            local trap_widget = {}
            -- Do not fork an already-open SQLite connection.  The child opens
            -- its own WAL connection and the reader may reopen one later.
            self.cache:close()
            local completed, result = Trapper:dismissableRunInSubprocess(function()
                local ok, info, err = pcall(DocumentAdapter.translate, {
                    book_path = book_path,
                    fragment = fragment,
                    target_lang = self:getTargetLang(),
                    source_lang = self:getSourceLang(),
                    translate = function(text)
                        return self:translateDocumentText(text)
                    end,
                    translate_batch = function(texts)
                        return self:translateDocumentTextBatch(texts)
                    end,
                    all_chapters = all_chapters,
                    progress_path = progress_path,
                    control_path = control_path,
                    output_dir = self:getBookCacheDirectory(book_path),
                })
                if not ok then
                    logger.warn("kotranslate: translate_overlay crashed:", info)
                    return { error = "翻译过程异常：" .. tostring(info) }
                end
                if not info then return { error = err } end
                return info
            end, trap_widget)

            if not completed then
                close_progress()
                self._translation_progress.active = false
                if item.status == "aborting" then
                    self:removeTranslationQueueItem(item)
                    self:startNextQueuedTranslation()
                    return
                end
                item.status = "failed"
                item.error = "翻译已中断"
                self:saveTranslationQueue()
                if all_chapters then
                    -- Whole-book jobs are background jobs.  A transient
                    -- provider error or a reader restart must never cover the
                    -- page with a modal interruption message.  Keep the
                    -- resumable failed entry in the queue for an explicit
                    -- retry from the queue menu.
                    item.status = "queued"
                    item.error = nil
                    self:saveTranslationQueue()
                    logger.warn("kotranslate: background full-book translation interrupted; queued to resume")
                    UIManager:scheduleIn(2, function() self:startNextQueuedTranslation() end)
                else
                    UIManager:show(InfoMessage:new{ text = "翻译已中断。" })
                    self:startNextQueuedTranslation()
                end
                return
            end
            if result and result.aborted then
                close_progress()
                self._translation_progress.active = false
                self:removeTranslationQueueItem(item)
                self:startNextQueuedTranslation()
                return
            end
            if not result or not result.output then
                close_progress()
                self._translation_progress.active = false
                -- A killed translation subprocess can return no serialized
                -- value at all (most often after a transient memory spike
                -- from a previous interrupted job). Give a whole-book job
                -- one automatic clean retry instead of turning it into a
                -- permanent false failure.
                local retry_count = tonumber(item.retry_count) or 0
                if all_chapters and retry_count < 1 then
                    item.retry_count = retry_count + 1
                    item.status = "queued"
                    item.error = nil
                    self:saveTranslationQueue()
                    logger.warn("kotranslate: full-book worker returned no result; retrying once")
                    UIManager:scheduleIn(1, function()
                        self:startNextQueuedTranslation()
                    end)
                    return
                end
                item.status = "failed"
                item.error = (result and result.error) or "无法生成本书译文缓存"
                self:saveTranslationQueue()
                if all_chapters then
                    -- Do not interrupt reading for a background full-book
                    -- failure.  The queue entry keeps the error and can be
                    -- retried later; the log is available for diagnosis.
                    logger.warn("kotranslate: background full-book translation failed:", item.error)
                else
                    UIManager:show(InfoMessage:new{
                        text = (result and result.error) or "无法生成本书译文缓存。",
                    })
                end
                self:startNextQueuedTranslation()
                return
            end
            self._translation_progress.active = false
            close_progress()
            local result_failed = tonumber(result.failed) or 0
            if all_chapters and result_failed > 0 then
                item.output = result.output
                item.failed = result_failed
                local partial_retry = tonumber(item.partial_retry_count) or 0
                if partial_retry < 1 then
                    item.partial_retry_count = partial_retry + 1
                    item.status = "queued"
                    item.error = "有段落翻译失败，正在自动续跑"
                    self:saveTranslationQueue()
                    UIManager:scheduleIn(1, function()
                        self:startNextQueuedTranslation()
                    end)
                    return
                end
                item.status = "failed"
                item.error = string.format("仍有 %d 个段落未翻译，可从队列重试", result_failed)
                self:saveTranslationQueue()
                self:startNextQueuedTranslation()
                return
            end
            item.status = "done"
            item.output = result.output
            item.current = result.translated or item.current
            item.translated = result.translated or item.translated
            item.failed = result.failed or item.failed
            item.error = nil
            self:saveTranslationQueue()
            UIManager:show(InfoMessage:new{
                text = string.format("翻译完成\n已翻译段落：%d\n失败段落：%d", result.translated or 0, result.failed or 0),
                timeout = 3,
            })
            UIManager:scheduleIn(0.2, function()
                if self.ui and self.ui.document and self.ui.document.file == book_path then
                    self:saveSetting("translation_visible", true)
                    self:applyAssistRuntimeStyle()
                end
                self:startNextQueuedTranslation()
            end)
        end)
    end)
end

function kotranslate:isCacheEnabled()
    return self:getSetting("enable_cache", true)
end

function kotranslate:inlineStyleMenu(key, title, choices)
    local items = {}
    for _, choice in ipairs(choices) do
        table.insert(items, {
            text = choice.label,
            radio = true,
            checked_func = function() return self:getSetting(key) == choice.value end,
            callback = function()
                self:saveSetting(key, choice.value)
                if key == "assist_font_size" or key == "assist_color" then
                    -- Auxiliary text is painted directly on the framebuffer.
                    -- Never submit a new CRE stylesheet for these settings:
                    -- doing so asks KOReader for a full document rerender.
                    self:applyReadingLineSpacing()
                    self:resetRubyPaintCache()
                    self:scheduleReadingHints(0.01)
                    UIManager:setDirty("all", "ui")
                else
                    self:refreshTranslationStyle()
                end
            end,
        })
    end
    return {
        text = title,
        sub_item_table = items,
    }
end

function kotranslate:getInlineFontSize()
    local value = tostring(self:getSetting("inline_font_size", 16))
    local number = tonumber(value:match("[%d%.]+")) or 16
    if value:match("%%$") then
        number = 16 * number / 100
    elseif value:match("em$") then
        number = 16 * number
    end
    return math.floor(number + 0.5)
end

function kotranslate:getInlineFontFamilyCss()
    local family = self:getSetting("inline_font_family")
    if type(family) ~= "string" or family == "" then return "inherit" end
    return '"' .. family:gsub("\\", "\\\\"):gsub('"', '\\"') .. '"'
end

function kotranslate:getInlineFontCssSize()
    -- Treat 16 as the document's 1em base, matching KOReader's numeric font
    -- setting: 20 means 125% of the body text.
    return string.format("%.4gem", self:getInlineFontSize() / 16)
end

function kotranslate:getAssistFontCssSize()
    local value = tonumber(self:getSetting("assist_font_size", 40)) or 40
    value = math.max(30, math.min(100, value))
    return string.format("%.4g%%", value)
end

function kotranslate:getAssistColor()
    local value = tostring(self:getSetting("assist_color", "#4d4d4d"))
    if not value:match("^#%x%x%x%x%x%x$") then value = "#4d4d4d" end
    return value
end

-- Microsoft Edge accepts an array of texts and returns one translation per
-- item. Batch short paragraphs to reduce network round trips while keeping
-- the original paragraph boundaries for EPUB insertion.
function kotranslate:translateDocumentTextBatch(texts)
    if self:getMode() ~= "microsoft_free" then
        local results = {}
        local first_error
        for index, text in ipairs(texts) do
            local translated, err = self:translateDocumentText(text)
            if translated then
                results[index] = translated
            else
                results[index] = false
                first_error = first_error or err
            end
        end
        return results, first_error
    end

    local results = {}
    local pending = {}
    local first_error
    local limit = self:getTranslationChunkLimit()
    for index, text in ipairs(texts) do
        if #text > limit then
            local translated, err = self:translateDocumentText(text)
            if translated then
                results[index] = translated
            else
                results[index] = false
                first_error = first_error or err
            end
        elseif self:isCacheEnabled() then
            local cached = self.cache:lookupForBook(self._active_translation_book,
                self:getSourceLang(), self:getTargetLang(), text)
            if cached and cached.translated_text
                and not cached.translated_text:match("MYMEMORY%s+WARNING") then
                results[index] = cached.translated_text
            else
                table.insert(pending, { index = index, text = text })
            end
        else
            table.insert(pending, { index = index, text = text })
        end
    end

    local batch_start = 1
    while batch_start <= #pending do
        local batch, batch_texts = {}, {}
        local total_bytes = 0
        while batch_start <= #pending and #batch < 12 do
            local item = pending[batch_start]
            if #batch > 0 and total_bytes + #item.text > 4000 then break end
            table.insert(batch, item)
            table.insert(batch_texts, item.text)
            total_bytes = total_bytes + #item.text
            batch_start = batch_start + 1
        end
        local translated, err = Providers.translate_microsoft_free_batch(
            batch_texts, self:getSourceLang(), self:getTargetLang(), nil, {})
        if not translated then
            -- One immediate retry handles transient resets without falling
            -- back to a slow request for every paragraph.
            translated, err = Providers.translate_microsoft_free_batch(
                batch_texts, self:getSourceLang(), self:getTargetLang(), nil, {})
        end
        if not translated then
            -- A batch request can time out even though the single-text Edge
            -- endpoint is still responsive. Retry each item only after the
            -- two batch attempts failed; this keeps normal translation fast
            -- while allowing a long English book to recover from a transient
            -- batch failure instead of producing no EPUB at all.
            if err and (err.code ~= nil or err.message) then
                for _, item in ipairs(batch) do
                    local single, single_err = self:translateDocumentText(item.text)
                    if single then
                        results[item.index] = single
                    else
                        results[item.index] = false
                        first_error = first_error or single_err or err
                    end
                end
            else
                for _, item in ipairs(batch) do results[item.index] = false end
                first_error = first_error or err or { message = "翻译服务连接失败" }
            end
        else
            for offset, item in ipairs(batch) do
                local value = translated[offset]
                if value and value ~= "" and not value:match("MYMEMORY%s+WARNING") then
                    results[item.index] = value
                    if self:isCacheEnabled() then
                        self.cache:storeForBook(self._active_translation_book,
                            self:getSourceLang(), self:getTargetLang(), item.text,
                            value, "microsoft_free")
                    end
                else
                    results[item.index] = false
                    first_error = first_error or { message = "翻译服务返回了空译文" }
                end
            end
        end
    end
    return results, first_error
end

function kotranslate:refreshTranslationStyle()
    self:applyAssistRuntimeStyle()
end

-- Toggle pronunciation ruby at the reader level.  This is intentionally
-- separate from refreshTranslationStyle(): changing the display state
-- must not unzip/repack the EPUB or disturb the reading position.
function kotranslate:applyAssistRuntimeStyle()
    local document = self.ui and self.ui.document
    local typeset = self.ui and self.ui.typeset
    if not document or not typeset or not document.setStyleSheet then return false end
    -- CREngine's default TXT mode is preformatted (txt_preformatted=1).
    -- In that mode a TXT file is one text stream, not paragraph nodes, so a
    -- non-destructive CSS overlay has nowhere to attach.  Switch the book's
    -- own layout setting once, then let KOReader perform its normal reload.
    if document.is_txt and typeset.txt_preformatted == 1
        and self:hasTranslationOverlay(document.file)
        and not document._kotranslate_txt_layout_requested then
        local settings = self.ui.doc_settings
        if settings and settings.saveSetting then
            settings:saveSetting("txt_preformatted", 0)
            document._kotranslate_txt_layout_requested = true
            if self.ui.rolling and self.ui.rolling.showSuggestReloadConfirmBox then
                UIManager:scheduleIn(0.1, function()
                    self.ui.rolling:showSuggestReloadConfirmBox()
                end)
            end
        end
        return false
    end
    local css = typeset.css or document.default_css or ""
    local tweaks = self.ui.styletweak and self.ui.styletweak:getCssText() or ""
    local color = tostring(self:getSetting("inline_color", "#666666"))
    if not color:match("^#%x%x%x%x%x%x$") then color = "#666666" end
    local font_size = self:getInlineFontCssSize()
    local font_family = self:getInlineFontFamilyCss()
    local assist_color = self:getAssistColor()
    local assist_font_size = self:getAssistFontCssSize()
    local japanese_mode = self:getJapaneseAssistMode()
    local furigana_enabled = japanese_mode == "furigana" or japanese_mode == "both"
    local romaji_enabled = japanese_mode == "romaji" or japanese_mode == "both"
    local furigana_display = furigana_enabled and "ruby-text" or "none"
    local romaji_display = romaji_enabled and "ruby-text" or "none"
    local furigana_line_display = furigana_enabled and "block" or "none"
    local romaji_line_display = romaji_enabled and "block" or "none"
    local plugin_enabled = self:isPluginEnabled()
    local translation_css = string.format([[
.kotranslate-translation {
    color: %s !important;
    font-size: %s !important;
    font-family: %s !important;
    display: %s !important;
    visibility: visible !important;
    height: auto !important;
    max-height: none !important;
    overflow: visible !important;
    margin: 0 !important;
    padding: 0 !important;
}
]], color, font_size, font_family, plugin_enabled
        and self:getSetting("translation_visible", true) and "block" or "none")
    local assist_css
    if self:isAssistEnabled() then
        assist_css = [[
.kotranslate-ruby {
    ruby-position: over !important;
    ruby-align: start !important;
    line-height: normal !important;
    margin: 0 !important;
    padding: 0 !important;
    white-space: nowrap !important;
}
.kotranslate-ruby > rb {
    line-height: normal !important;
    margin: 0 !important;
    padding: 0 !important;
}
.kotranslate-ruby > rt,
.kotranslate-assist {
    display: ruby-text !important;
    color: %s !important;
    visibility: visible !important;
    font-size: %s !important;
    line-height: normal !important;
    margin: 0 !important;
    padding: 0 !important;
    white-space: nowrap !important;
}
.kotranslate-assist {
    vertical-align: over !important;
}
.kotranslate-assist-ja {
    display: ]] .. furigana_display .. [[ !important;
}
.kotranslate-assist-ja-romaji {
    display: ]] .. romaji_display .. [[ !important;
}
.kotranslate-assist-both {
    display: ruby-text !important;
}
.kotranslate-ja-part {
    display: ]] .. furigana_display .. [[ !important;
}
.kotranslate-romaji-part {
    display: ]] .. romaji_display .. [[ !important;
}
.kotranslate-ja-lines {
    margin: 0 !important;
    padding: 0 !important;
}
.kotranslate-ja-romaji-line,
.kotranslate-ja-furigana-line {
    color: %s !important;
    font-size: %s !important;
    line-height: normal !important;
    margin: 0 !important;
    padding: 0 !important;
}
.kotranslate-ja-romaji-line {
    display: ]] .. romaji_line_display .. [[ !important;
}
.kotranslate-ja-furigana-line {
    display: ]] .. furigana_line_display .. [[ !important;
}
.kotranslate-ja-original-line {
    display: block !important;
}
.kotranslate-assist-zh {
    display: none !important;
    visibility: hidden !important;
}
.kotranslate-translation .kotranslate-ruby,
.kotranslate-translation .kotranslate-assist {
    display: none !important;
    visibility: hidden !important;
}
]]
    else
        -- CRE may ignore display:none on ruby <rt>; zero-size transparent
        -- text hides it without changing the base line or EPUB contents.
        assist_css = [[
.kotranslate-assist {
    display: none !important;
    color: transparent !important;
    visibility: hidden !important;
    font-size: 0 !important;
    line-height: 0 !important;
}
rt.kotranslate-assist {
    display: none !important;
}
]]
    end
    assist_css = string.format(assist_css, assist_color, assist_font_size,
        assist_color, assist_font_size)
    -- EPUBs may already contain <ruby>/<rt>.  While our Japanese layer is on,
    -- hide that built-in reading so "romaji only" cannot still appear to show
    -- kana.  Our selected layer is painted independently above the base word.
    local native_ruby_css = ""
    if japanese_mode ~= "off" then
        native_ruby_css = [[
ruby > rt {
    display: none !important;
    visibility: hidden !important;
    color: transparent !important;
    font-size: 0 !important;
    line-height: 0 !important;
}
]]
    end
    local book_path = document.file
    local overlay_css = ""
    if book_path then
        overlay_css = Overlay.buildCss(self:getTranslationOverlayPath(book_path), {
            translation_visible = plugin_enabled
                and self:getSetting("translation_visible", true) == true,
            assist_enabled = self:isAssistEnabled(),
            furigana_enabled = furigana_enabled,
            romaji_enabled = romaji_enabled,
            english_enabled = self:isEnglishAssistEnabled(),
            translation_color = color,
            translation_size = font_size,
            translation_font_family = font_family,
            assist_color = assist_color,
            assist_size = assist_font_size,
        })
    end
    self:resetRubyPaintCache()
    -- Auxiliary readings are framebuffer overlays. Keep them completely out
    -- of CRE's stylesheet so changing Japanese mode, size or colour cannot
    -- request a full document rerender. Native EPUB ruby remains untouched.
    local extra_css = tweaks .. "\n" .. translation_css .. "\n" .. overlay_css
    -- Keep this marker on the document object, which survives the rerender
    -- that setStyleSheet itself initiates.  A plugin instance may be rebuilt
    -- during that rerender, so an instance-local flag cannot stop the loop.
    if document._kotranslate_extra_css == extra_css then
        self:applyReadingLineSpacing()
        return true
    end
    document._kotranslate_extra_css = extra_css
    local ok = pcall(function()
        document:setStyleSheet(css, extra_css)
    end)
    if ok then
        self:applyReadingLineSpacing()
    else
        document._kotranslate_extra_css = nil
    end
    return ok
end

function kotranslate:applyReadingLineSpacing()
    local document = self.ui and self.ui.document
    if not document or not document.setInterlineSpacePercent then return end
    local rows = 0
    if self:isAssistEnabled() then
        if self:isJapaneseRomajiEnabled() then rows = rows + 1 end
        if self:isJapaneseAssistEnabled() then rows = rows + 1 end
        if rows == 0 and self:isEnglishAssistEnabled() then rows = 1 end
    end
    local configurable = self.ui and self.ui.font and self.ui.font.configurable
    if not configurable then return end
    local settings = self.ui and self.ui.doc_settings
    local original = settings and settings:readSetting("kotranslate_original_line_spacing")
    if rows > 0 and not original then
        original = configurable.line_spacing or 100
        if settings then settings:saveSetting("kotranslate_original_line_spacing", original) end
    end
    local target
    if rows > 0 then
        local assist_percent = tonumber(self:getSetting("assist_font_size", 40)) or 40
        assist_percent = math.max(30, math.min(60, assist_percent))
        -- Reserve one annotation-font share per enabled row.  This scales
        -- with both the document font and the selected assist size, so the
        -- same layout works on different resolutions and font settings.
        -- Reserve annotation space on top of the user's own line spacing.
        -- Using max(original, 100 + reserve) left almost no space whenever
        -- the book already used a large line spacing, which made the overlay
        -- collide with the body text after a reload.
        target = math.floor((original or 100) + rows * assist_percent + 0.5)
    else
        target = original or configurable.line_spacing or 100
    end
    if configurable.line_spacing == target then
        self._reading_original_line_spacing = original or 100
        self._reading_line_spacing = target
        return
    end
    configurable.line_spacing = target
    self._reading_original_line_spacing = original or 100
    self._reading_line_spacing = target
    document:setInterlineSpacePercent(target)
    if rows == 0 and settings then
        settings:delSetting("kotranslate_original_line_spacing")
    end
    if self.ui and self.ui.handleEvent then
        self.ui:handleEvent(Event:new("UpdatePos"))
    end
end

function kotranslate:resetRubyPaintCache()
    self._reading_hints = nil
    self._reading_page = nil
    self._reading_document = nil
    self._reading_hint_cache = nil
end

local function utf8_length(text)
    local count = 0
    for _ in tostring(text or ""):gmatch("[%z\1-\127\194-\244][\128-\191]*") do
        count = count + 1
    end
    return count
end

local function advance_visible_char(document, xpointer, count)
    local current = xpointer
    for _ = 1, count do
        current = current and document:getNextVisibleChar(current)
        if not current then break end
    end
    return current
end

-- Enumerate only the words CREngine says are
-- visible on this page, then anchor every annotation to that word's real
-- XPointer and screen box.  Never derive screen positions from EPUB paragraph
-- offsets: markup, entities and reflow make those offsets unsuitable here.
function kotranslate:computeReadingHints()
    self._reading_hints = {}
    self._reading_page = nil
    self._reading_document = nil
    local document = self.ui and self.ui.document
    if not self:isAssistEnabled() then
        -- Mark the empty result as belonging to the current page.  This keeps
        -- the paint safety net from treating a deliberately disabled layer as
        -- a missed page that needs another calculation.
        self._reading_page = document and document:getCurrentPage() or nil
        self._reading_document = document and tostring(document.file or "") or nil
        return
    end
    if not document or not document.getNextVisibleWordStart
        or not document.getNextVisibleChar
        or not document.getScreenBoxesFromPositions
        or not document.getPageFromXPointer then return end
    local page = document:getCurrentPage()
    local document_path = tostring(document.file or "")
    local cache_key = document_path .. "\0" .. tostring(page)
    self._reading_hint_cache = self._reading_hint_cache or {}
    if self._reading_hint_cache[cache_key] then
        self._reading_hints = self._reading_hint_cache[cache_key]
        self._reading_page = page
        self._reading_document = document_path
        return
    end
    local start_xp = document:getPageXPointer(page)
    if not start_xp then return end
    local end_xp = document:getPageXPointer(page + 1)
    self._reading_page = page
    self._reading_document = document_path

    local spans, page_text, text_position = {}, {}, 1
    local english_words, english_seen = {}, {}
    local function xpointer_on_page(xp)
        return xp and document:getPageFromXPointer(xp) == page
    end
    local function xpointer_before_page_end(xp)
        if not xp then return false end
        if end_xp and document.compareXPointers then
            -- compareXPointers(a, b) returns 1 when b is after a.
            local ordered = document:compareXPointers(xp, end_xp)
            if ordered ~= nil then return ordered == 1 end
        end
        return xpointer_on_page(xp)
    end
    local function visible_box(boxes)
        if not boxes then return nil end
        local screen_height = Screen:getHeight()
        local screen_width = Screen:getWidth()
        local merged
        for _, box in ipairs(boxes) do
            if box.w > 0 and box.h > 0
                and box.y < screen_height and box.y + box.h > 0
                and box.x < screen_width and box.x + box.w > 0 then
                if not merged then
                    merged = {
                        x = box.x, y = box.y,
                        right = box.x + box.w, bottom = box.y + box.h,
                        center = box.y + box.h / 2,
                    }
                else
                    -- CRE may return one segment box per kanji (not one box
                    -- per word). Merge every segment on this visual line so
                    -- compounds such as 恐怖 receive one centred きょうふ
                    -- annotation instead of a reading anchored to one glyph.
                    local center = box.y + box.h / 2
                    local tolerance = math.max(4,
                        math.min(box.h, merged.bottom - merged.y) * 0.3)
                    if math.abs(center - merged.center) <= tolerance then
                        merged.x = math.min(merged.x, box.x)
                        merged.y = math.min(merged.y, box.y)
                        merged.right = math.max(merged.right, box.x + box.w)
                        merged.bottom = math.max(merged.bottom, box.y + box.h)
                    end
                end
            end
        end
        if merged then
            return {
                x = merged.x, y = merged.y,
                w = merged.right - merged.x,
                h = merged.bottom - merged.y,
            }
        end
    end
    local function merge_adjacent_single_kanji(items)
        local merged = {}
        for _, item in ipairs(items) do
            local previous = merged[#merged]
            local previous_box = previous and previous.box
            local box = item.box
            local same_line = previous_box and box
                and math.abs((previous_box.y + previous_box.h / 2)
                    - (box.y + box.h / 2))
                    <= math.max(4, math.min(previous_box.h, box.h) * 0.3)
            local gap = same_line
                and box.x - (previous_box.x + previous_box.w) or math.huge
            if previous and previous.kind == "japanese"
                and item.kind == "japanese"
                and utf8_length(previous.base or "") == 1
                and utf8_length(item.base or "") == 1
                and gap >= -2 and gap <= math.max(6, math.min(previous_box.h, box.h) * 0.25) then
                local right = math.max(previous_box.x + previous_box.w, box.x + box.w)
                local bottom = math.max(previous_box.y + previous_box.h, box.y + box.h)
                previous_box.x = math.min(previous_box.x, box.x)
                previous_box.y = math.min(previous_box.y, box.y)
                previous_box.w = right - previous_box.x
                previous_box.h = bottom - previous_box.y
                previous.base = (previous.base or "") .. (item.base or "")
                previous.furigana = (previous.furigana or "") .. (item.furigana or "")
                previous.romaji = (previous.romaji or "") .. (item.romaji or "")
            else
                merged[#merged + 1] = item
            end
        end
        return merged
    end
    local xp = document:getNextVisibleWordStart(start_xp)
    local guard = 0
    while xp and guard < 4000 do
        guard = guard + 1
        -- isXPointerInCurrentPage() can lag behind CRE's reflow state and
        -- used to stop the scan at the first paragraph on some pages.  The
        -- document's page resolver is stable for both ends of a reflowed page.
        if not xpointer_before_page_end(xp) then break end
        local end_xp = document:getNextVisibleWordEnd(xp)
        if not end_xp then break end
        local word = document:getTextFromXPointers(xp, end_xp)
        if word and word ~= "" then
            local length = utf8_length(word)
            spans[#spans + 1] = {
                start = text_position, length = length,
                xpointer = xp, end_xpointer = end_xp, text = word,
            }
            local english = word:gsub("[^%a']", "")
            if #english >= 3 and not english_seen[english:lower()] then
                english_seen[english:lower()] = true
                english_words[#english_words + 1] = english
            end
            page_text[#page_text + 1] = word
            text_position = text_position + length + 1
        end
        local next_xp = document:getNextVisibleWordStart(end_xp)
        if not next_xp or next_xp == xp then break end
        xp = next_xp
    end

    local wants_japanese = self:isJapaneseAssistEnabled()
        or self:isJapaneseRomajiEnabled()
    -- Japanese uses its own character iterator below. Do not make it depend
    -- on CRE's word iterator: at chapter/page boundaries that iterator may
    -- legitimately return no words even though the page contains Japanese.
    if #spans == 0 and not wants_japanese then return end
    if #english_words > 0 then
        local definitions = self:lookupAssistBatch("english_exam", english_words)
        for _, span in ipairs(spans) do
            local word = span.text:gsub("[^%a']", "")
            local gloss = definitions[word] or definitions[word:lower()]
            if gloss and gloss ~= false then
                local boxes = document:getScreenBoxesFromPositions(
                    span.xpointer, span.end_xpointer, true)
                local box = visible_box(boxes)
                if box then
                    self._reading_hints[#self._reading_hints + 1] = {
                        box = box, text = gloss, kind = "english",
                    }
                end
            end
        end
    end

    local tokens = {}
    if wants_japanese then
        local japanese_spans, japanese_text = {}, {}
        local char_xp = start_xp
        local char_position = 1
        local char_guard = 0
        local overscan_count = 0
        -- Scan the actual XPointer interval [this page, next page). Page-start
        -- pointers may resolve to the preceding page at a node boundary, so a
        -- getPageFromXPointer equality check can incorrectly discard a whole
        -- otherwise valid page.
        -- CRE's visible-word iterator can omit Japanese paragraphs. Walk
        -- visible characters for the Japanese layer so every paragraph has a
        -- stable source position, including kana-only words and short lines.
        while char_xp and char_guard < 12000 do
            if not xpointer_before_page_end(char_xp) then
                -- Translation pseudo-elements can make the visible bottom of
                -- a bilingual page extend beyond CRE's original page-end
                -- XPointer. Scan a bounded tail and let real screen boxes,
                -- rather than stale pagination metadata, decide visibility.
                if not end_xp or overscan_count >= 512 then break end
                overscan_count = overscan_count + 1
            end
            char_guard = char_guard + 1
            local next_xp = document:getNextVisibleChar(char_xp)
            if not next_xp or next_xp == char_xp then break end
            local character = document:getTextFromXPointers(char_xp, next_xp)
            local length = utf8_length(character or "")
            if character and character ~= "" and length > 0 then
                japanese_spans[#japanese_spans + 1] = {
                    start = char_position, length = length,
                    xpointer = char_xp, end_xpointer = next_xp,
                }
                japanese_text[#japanese_text + 1] = character
                char_position = char_position + length
            end
            char_xp = next_xp
        end
        local source_text = #japanese_spans > 0
            and table.concat(japanese_text) or table.concat(page_text, "\n")
        local native_tokens = {}
        if document.getHTMLFromXPointers and end_xp then
            local ok_html, page_html = pcall(document.getHTMLFromXPointers,
                document, start_xp, end_xp, 0x1001, false)
            if ok_html and page_html then
                native_tokens = Assist.getNativeJapaneseTokens(
                    page_html, source_text)
            end
        end
        -- Do not run the Japanese kanji fallback on Chinese text.  The
        -- fallback intentionally accepts kanji-only words, so using the
        -- setting alone made a Chinese book look Japanese whenever Japanese
        -- assist had been left enabled from the previous book.
        if Assist.hasJapaneseScript(source_text) then
            tokens = Assist.getJapaneseTokens(source_text,
                function(kind, words) return self:lookupAssistBatch(kind, words) end)
        else
            tokens = {}
        end
        if #native_tokens > 0 then
            local merged = {}
            for _, token in ipairs(tokens) do
                local token_start = tonumber(token.start) or 0
                local token_end = token_start + (tonumber(token.length) or 0) - 1
                local overlaps_native = false
                for _, native in ipairs(native_tokens) do
                    local native_start = tonumber(native.start) or 0
                    local native_end = native_start
                        + (tonumber(native.length) or 0) - 1
                    if token_start <= native_end and token_end >= native_start then
                        overlaps_native = true
                        break
                    end
                end
                if not overlaps_native then merged[#merged + 1] = token end
            end
            for _, native in ipairs(native_tokens) do
                merged[#merged + 1] = native
            end
            table.sort(merged, function(a, b)
                return (tonumber(a.start) or 0) < (tonumber(b.start) or 0)
            end)
            tokens = merged
        end
        if #japanese_spans > 0 then
            local first_index = 1
            for _, token in ipairs(tokens or {}) do
                local token_start = tonumber(token.start) or 0
                local token_length = tonumber(token.length) or 0
                local first, last
                while japanese_spans[first_index]
                    and token_start >= japanese_spans[first_index].start
                        + japanese_spans[first_index].length do
                    first_index = first_index + 1
                end
                local first_span = japanese_spans[first_index]
                if first_span and token_start >= first_span.start
                    and token_start < first_span.start + first_span.length then
                    first = first_index
                end
                if first and token_length > 0 then
                    local end_position = token_start + token_length - 1
                    for index = first, #japanese_spans do
                        local span = japanese_spans[index]
                        if end_position < span.start + span.length then
                            last = index
                            break
                        end
                    end
                    if last then
                        local range_start = japanese_spans[first].xpointer
                        local range_end = japanese_spans[last].end_xpointer
                        local boxes = document:getScreenBoxesFromPositions(
                            range_start, range_end, true)
                        local box = visible_box(boxes)
                        if box then
                            self._reading_hints[#self._reading_hints + 1] = {
                                box = box, furigana = token.furigana,
                                romaji = token.romaji, base = token.base,
                                kind = "japanese",
                            }
                        end
                    end
                end
            end
            self._reading_hints = merge_adjacent_single_kanji(self._reading_hints)
            self._reading_hint_cache[cache_key] = self._reading_hints
            return
        end
    end
    local span_index = 1
    for _, token in ipairs(tokens or {}) do
        local token_start = tonumber(token.start) or 0
        while spans[span_index]
            and token_start >= spans[span_index].start + spans[span_index].length do
            span_index = span_index + 1
        end
        local span = spans[span_index]
        local token_length = tonumber(token.length) or 0
        if span and token_start >= span.start and token_length > 0
            and token_start + token_length <= span.start + span.length then
            local local_offset = token_start - span.start
            local range_start = advance_visible_char(document, span.xpointer, local_offset)
            local range_end = advance_visible_char(document, range_start, token_length)
                or span.end_xpointer
            if range_start and range_end then
                local boxes = document:getScreenBoxesFromPositions(range_start, range_end, true)
                local box = visible_box(boxes)
                if box then
                    self._reading_hints[#self._reading_hints + 1] = {
                        box = box, furigana = token.furigana,
                        romaji = token.romaji, base = token.base,
                        kind = "japanese",
                    }
                end
            end
        end
    end
    self._reading_hints = merge_adjacent_single_kanji(self._reading_hints)
    self._reading_hint_cache[cache_key] = self._reading_hints
end

function kotranslate:paintTo(bb, x, y)
    if not self:isAssistEnabled() then return end
    local document = self.ui and self.ui.document
    local page = document and document:getCurrentPage()
    local document_path = document and tostring(document.file or "")
    if page ~= self._reading_page or document_path ~= self._reading_document then
        -- Some KOReader navigation paths do not emit PageUpdate/PosUpdate.
        -- Painting is guaranteed for every displayed page, so use it as a
        -- non-blocking safety net and calculate the missed page immediately.
        if self.scheduleReadingHints then self:scheduleReadingHints(0) end
        return
    end
    local items = self._reading_hints or {}
    if #items == 0 then return end
    local percent = tonumber(self:getSetting("assist_font_size", 40)) or 40
    -- The setting remains a percentage in the menu, but it scales a stable
    -- Compact overlay face; CREngine's document font size is not a
    -- framebuffer pixel size and was the cause of the giant annotations.
    local font_size = math.max(6, math.min(20, math.floor(10 * percent / 55 + 0.5)))
    local face = Font:getFace("infofont", font_size)
    local configured_color = self:getAssistColor()
    local color = configured_color:match("^#%x%x%x%x%x%x$")
        and Blitbuffer.colorFromString(configured_color)
        or Blitbuffer.colorFromName(configured_color)
        or Blitbuffer.COLOR_DARK_GRAY
    local show_furigana = self:isJapaneseAssistEnabled()
    local show_romaji = self:isJapaneseRomajiEnabled()
    local metrics = RenderText:sizeUtf8Text(0, bb:getWidth(), face, "Agあ", true, false)
    local ascent = metrics.y_top or font_size
    local descent = math.max(0, metrics.y_bottom or 2)
    local line_height = math.max(font_size + 2, ascent + descent + 1)
    local spacing = self._reading_line_spacing or 180
    local original_spacing = self._reading_original_line_spacing or 100

    local function fit_line(text, max_width)
        local metrics = RenderText:sizeUtf8Text(
            0, nil, face, text, true, false)
        if metrics.x <= max_width then return text, metrics end
        local chars = {}
        for char in tostring(text):gmatch("[%z\1-\127\194-\244][\128-\191]*") do
            chars[#chars + 1] = char
        end
        local low, high, best = 0, #chars, "…"
        while low <= high do
            local middle = math.floor((low + high) / 2)
            local candidate = table.concat(chars, "", 1, middle) .. "…"
            local candidate_metrics = RenderText:sizeUtf8Text(
                0, nil, face, candidate, true, false)
            if candidate_metrics.x <= max_width then
                best = candidate
                low = middle + 1
            else
                high = middle - 1
            end
        end
        return best, RenderText:sizeUtf8Text(
            0, nil, face, best, true, false)
    end

    local function get_lines(item)
        local lines = {}
        if item.kind == "english" then
            if item.text and item.text ~= "" then lines[1] = item.text end
        else
            if show_romaji and item.romaji and item.romaji ~= "" then
                lines[#lines + 1] = item.romaji
            end
            if show_furigana and item.furigana and item.furigana ~= "" then
                lines[#lines + 1] = item.furigana
            end
        end
        return lines
    end

    -- CRE boxes include line-height leading. Group words by visual row and
    -- calculate one real body-text top; this is the only vertical anchor.
    local rows = {}
    local row_for_item = {}
    for _, item in ipairs(items) do
        local box = item.box
        if box and #get_lines(item) > 0 then
            local center = box.y + box.h / 2
            local row_index
            for index, row in ipairs(rows) do
                local tolerance = math.max(1,
                    math.min(box.h, row.height) * 0.25)
                if math.abs(center - row.center) <= tolerance then
                    row_index = index
                    break
                end
            end
            if not row_index then
                row_index = #rows + 1
                rows[row_index] = {
                    center = center,
                    height = box.h,
                    body_top_sum = 0,
                    count = 0,
                    occupied = {},
                }
            end
            local row = rows[row_index]
            local leading = box.h * (1 - original_spacing / spacing)
            local body_top = box.y + leading / 2
            row.count = row.count + 1
            row.center = row.center + (center - row.center) / row.count
            row.height = math.max(row.height, box.h)
            row.body_top_sum = row.body_top_sum + body_top
            row_for_item[item] = row_index
        end
    end
    for _, row in ipairs(rows) do
        row.body_top = row.body_top_sum / row.count
    end
    for _, item in ipairs(items) do
        local lines = get_lines(item)
        local box = item.box
        local row = row_for_item[item] and rows[row_for_item[item]]
        if box and row and #lines > 0 then
            if item.kind == "english" then
                local leading = box.h * (1 - original_spacing / spacing)
                local underline_y = math.floor(box.y + box.h - leading / 2 + 0.5)
                bb:paintRect(x + math.floor(box.x), y + underline_y,
                    math.max(1, math.floor(box.w + 0.5)), 1, color)
            end
            local widths, text_metrics, max_width = {}, {}, 0
            local maximum_text_width = math.max(font_size * 4,
                bb:getWidth() - font_size * 2)
            for index, line in ipairs(lines) do
                lines[index], text_metrics[index] = fit_line(
                    line, maximum_text_width)
                widths[index] = text_metrics[index].x
                max_width = math.max(max_width, widths[index])
            end
            local centre = box.x + box.w / 2
            local left = math.max(font_size,
                math.min(centre - max_width / 2,
                    bb:getWidth() - font_size - max_width))
            local interval = { left, left + max_width }
            local fits = true
            local padding = font_size * 0.5
            for _, existing in ipairs(row.occupied) do
                if interval[1] < existing[2] + padding
                    and interval[2] + padding > existing[1] then
                    fits = false
                    break
                end
            end
            if fits then
                row.occupied[#row.occupied + 1] = interval
                local gap = math.max(1, math.floor(line_height * 0.12 + 0.5))
                local nearest_top = row.body_top - gap - line_height
                if item.kind == "english" then
                    -- English definitions are shorter and have no second
                    -- Japanese row beneath them. Keep them visually attached
                    -- to their word instead of drifting toward the line above.
                    nearest_top = nearest_top
                        + math.floor(line_height * 0.35 + 0.5)
                end
                for index, line in ipairs(lines) do
                    local draw_x = math.floor(left + (max_width - widths[index]) / 2 + 0.5)
                    local target_top = nearest_top - (#lines - index) * line_height
                    local baseline = math.floor(
                        target_top + (text_metrics[index].y_top or ascent) + 0.5)
                    if baseline > 2 then
                        RenderText:renderUtf8Text(bb, x + draw_x, y + baseline,
                            face, line, true, false, color)
                    end
                end
            end
        end
    end
end

function kotranslate:showInlineFontDialog()
    local dialog
    dialog = InputDialog:new{
        title = "译文字号",
        input = tostring(self:getInlineFontSize()),
        input_hint = "输入 8–40，例如 20",
        buttons = {{
            {
                text = "取消",
                id = "close",
                callback = function() UIManager:close(dialog) end,
            },
            {
                text = "保存",
                is_enter_default = true,
                callback = function()
                    local value = tonumber(dialog:getInputText())
                    if value then
                        value = math.floor(value + 0.5)
                        value = math.max(8, math.min(40, value))
                        self:saveSetting("inline_font_size", value)
                        self:refreshTranslationStyle()
                    end
                    UIManager:close(dialog)
                end,
            },
        }},
    }
    UIManager:show(dialog)
    dialog:onShowKeyboard()
end

------------------------------------------------------------------------
-- Core translate function
------------------------------------------------------------------------
function kotranslate:translateText(text, from_highlight, index)
    if not text or text == "" then
        TranslationUI.showError(_("No text to translate"))
        return
    end

    local mode = self:getMode()
    local source_lang = self:getSourceLang()
    local target_lang = self:getTargetLang()
    local book_path = self.ui and self.ui.document and self.ui.document.file or nil

    -- Check cache first (if enabled)
    if self:isCacheEnabled() then
        local cached = self.cache:lookup(source_lang, target_lang, text)
        if cached then
            TranslationUI.showTranslation(text, cached, source_lang, target_lang, from_highlight, index)
            return
        end
    end

    TranslationUI.showInfo(_("Translating..."), 1)

    local result, err
    result, err = Providers.translate(mode, text, source_lang, target_lang)

    if result then
        logger.dbg("kotranslate: translation result:", result)
        
        -- Ensure result has translated_text field
        if not result.translated_text then
            logger.warn("kotranslate: result missing translated_text field")
            TranslationUI.showError(_("Invalid response from translation service"))
            return
        end
        
        -- Cache the result (if enabled)
        if self:isCacheEnabled() then
            self.cache:store(source_lang, target_lang, text, result.translated_text,
                result.provider or mode, book_path)
        end
        TranslationUI.showTranslation(text, result, source_lang, target_lang, from_highlight, index)
    else
        logger.warn("kotranslate: translation failed:", err)
        local msg = err and err.message or _("Translation failed")
        TranslationUI.showError(msg)
    end
end

end

return Reader
