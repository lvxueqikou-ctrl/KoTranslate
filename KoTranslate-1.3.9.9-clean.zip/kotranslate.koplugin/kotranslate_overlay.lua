-- Non-destructive, per-book inline layers for EPUB documents.
-- The original archive is never modified.  Translations and pronunciation
-- lines are persisted as JSON and exposed to CREngine as generated CSS text.

local JSON = require("json")

local Overlay = {}

local function read_file(path)
    local file = io.open(path, "rb")
    if not file then return nil end
    local data = file:read("*a")
    file:close()
    return data
end

local function write_file(path, data)
    local temporary = path .. ".tmp"
    local file = io.open(temporary, "wb")
    if not file then return false end
    file:write(data)
    file:close()
    os.remove(path)
    if not os.rename(temporary, path) then
        os.remove(temporary)
        return false
    end
    return true
end

local function css_string(value)
    value = tostring(value or "")
    value = value:gsub("\\", "\\\\"):gsub('"', '\\"')
    value = value:gsub("\r\n", "\\A "):gsub("[\r\n]", "\\A ")
    value = value:gsub("%z", "")
    return '"' .. value .. '"'
end

function Overlay.load(path)
    local raw = read_file(path)
    if not raw or raw == "" then return nil end
    local ok, data = pcall(JSON.decode, raw)
    if not ok or type(data) ~= "table" or type(data.entries) ~= "table" then
        return nil
    end
    return data
end

function Overlay.save(path, data)
    local ok, encoded = pcall(JSON.encode, data)
    if not ok or not encoded then return false end
    return write_file(path, encoded)
end

function Overlay.exists(path)
    local file = io.open(path, "rb")
    if not file then return false end
    local size = file:seek("end") or 0
    file:close()
    return size > 0
end

-- CREngine implements generated ::before/::after content as real layout
-- nodes.  It therefore participates in pagination without touching EPUB
-- XHTML.  Rebuilding this CSS only changes the visible layers.
function Overlay.buildCss(path, options)
    local data = Overlay.load(path)
    if not data then return "" end
    options = options or {}
    local translation_visible = options.translation_visible == true
    local translation_color = options.translation_color or "#666666"
    local translation_size = options.translation_size or "1em"
    local translation_font_family = options.translation_font_family or "inherit"
    local rules = {
        "/* KOTranslate non-destructive generated layers */",
    }
    for _, entry in ipairs(data.entries) do
        local selector = entry.selector
        if selector and selector ~= "" then
            -- Older TXT overlays stored only body > p.  Some CREngine
            -- versions expose plain-text paragraphs without the body
            -- wrapper, so add the portable fallback when reading old cache.
            local txt_index = selector:match("^body%s*>%s*p:nth%-of%-type%((%d+)%)")
            if txt_index then
                -- Depending on TXT auto-layout and the CRE version, a line
                -- may be exposed as a p sibling or as a div sibling.  Keep
                -- all alternatives in separate CSS rules below.
                selector = table.concat({
                    selector,
                    "body p:nth-of-type(" .. txt_index .. ")",
                    "p:nth-of-type(" .. txt_index .. ")",
                    "body > div:nth-of-type(" .. txt_index .. ")",
                    "div:nth-of-type(" .. txt_index .. ")",
                }, ",")
            end
            if translation_visible and entry.translation and entry.translation ~= "" then
                -- Keep each TXT fallback as its own rule.  Older CRE CSS
                -- parsers can reject a selector list combined with ::after,
                -- which would hide both alternatives.
                for single_selector in selector:gmatch("[^,]+") do
                    single_selector = single_selector:gsub("^%s+", "")
                        :gsub("%s+$", "")
                    table.insert(rules, string.format(
                        "%s::after{content:%s!important;display:block!important;white-space:pre-wrap!important;color:%s!important;font-size:%s!important;font-family:%s!important;line-height:130%%!important;margin:0!important;padding:0!important;}",
                        single_selector, css_string(entry.translation), translation_color,
                        translation_size, translation_font_family))
                end
            end
        end
    end
    return table.concat(rules, "\n")
end

return Overlay
