local Device = require("device")
local UIManager = require("ui/uimanager")
local WidgetContainer = require("ui/widget/container/widgetcontainer")
local Screen = Device.screen
local logger = require("logger")
local _ = require("gettext")
local T = require("ffi/util").template

local Cache = require("kotranslate_cache")
local Providers = require("kotranslate_providers")
local TranslationUI = require("kotranslate_ui")
local Languages = require("kotranslate_languages")
local Assist = require("kotranslate_assist")
local Dictionaries = require("kotranslate_dictionaries")
local State = require("kotranslate_state")
local Reader = require("kotranslate_reader")

local kotranslate = WidgetContainer:extend{
    name = "kotranslate",
    is_doc_only = false,
}

local function stable_path_hash(value)
    local hash = 7
    for index = 1, #value do
        hash = (hash * 131 + value:byte(index)) % 2147483647
    end
    return string.format("%08x", hash)
end

function kotranslate:init()
    State.attach(self)
    Reader.attach(self)
    self.config_path = self.path .. "/kotranslate_configuration.lua"
    self:loadConfig()
    self.cache = Cache:new()
    self._translation_queue = self:loadTranslationQueue()
    -- Persist cleanup of completed entries immediately after startup.
    self:saveTranslationQueue()

    self.ui.menu:registerToMainMenu(self)

    -- Override KOReader's built-in Translate if mode is not "default"
    self:syncTranslateOverride()

    -- The reader hooks open the companion after document-ready. Keep the
    -- queue startup here, but do not replace a document during init.
    self:startNextQueuedTranslation()
end

-- Persistent configuration and translation-queue state lives in kotranslate_state.lua.

------------------------------------------------------------------------
-- Translator Override (like assistant.koplugin)
------------------------------------------------------------------------
function kotranslate:syncTranslateOverride()
    local Translator = require("ui/translator")
    local mode = self:isPluginEnabled() and self:getMode() or "default"

    if mode ~= "default" then
        -- Store original method if not already stored
        if not Translator._ogt_original_showTranslation then
            Translator._ogt_original_showTranslation = Translator.showTranslation
        end

        -- Override the translate method
        local plugin = self
        Translator.showTranslation = function(tr_self, text, detailed_view, source_lang, target_lang, from_highlight, index)
            local current_path = plugin.ui and plugin.ui.document and plugin.ui.document.file
            if not plugin:isTranslationManagedBook(current_path) then
                return Translator._ogt_original_showTranslation(
                    tr_self, text, detailed_view, source_lang, target_lang, from_highlight, index)
            end
            plugin:translateText(text, from_highlight, index)
        end
        logger.info("kotranslate: translate method overridden (mode:", mode, ")")
    else
        -- Restore original method
        if Translator._ogt_original_showTranslation then
            Translator.showTranslation = Translator._ogt_original_showTranslation
            Translator._ogt_original_showTranslation = nil
            logger.info("kotranslate: translate method restored to default")
        end
    end
end

-- A book enters translation scope only after it has an overlay or a queued
-- task. Auxiliary reading remains independent and works without translation.
function kotranslate:isTranslationManagedBook(book_path)
    if not book_path then return false end
    if self:hasTranslationOverlay(book_path) then return true end
    if self._active_translation_book == book_path then return true end
    for _, item in ipairs(self._translation_queue or {}) do
        if item.book_path == book_path then return true end
    end
    return false
end

------------------------------------------------------------------------
-- Settings helpers
------------------------------------------------------------------------
function kotranslate:getSetting(key, default)
    local val = self.config[key]
    if val == nil then
        return default
    end
    return val
end

function kotranslate:saveSetting(key, value)
    self.config[key] = value
    self:saveConfig()
end

function kotranslate:isPluginEnabled()
    return self:getSetting("plugin_enabled", true) == true
end

function kotranslate:togglePluginEnabled(menu)
    local enabled = not self:isPluginEnabled()
    self:saveSetting("plugin_enabled", enabled)
    self:syncTranslateOverride()
    self:resetRubyPaintCache()
    if self.applyAssistRuntimeStyle then
        self:applyAssistRuntimeStyle()
    elseif self.applyReadingLineSpacing then
        self:applyReadingLineSpacing()
    end
    if enabled then
        self:startNextQueuedTranslation()
        self:scheduleReadingHints(0.01)
    else
        self._reading_hints = {}
        UIManager:setDirty("all", "ui")
    end
    if menu and menu.updateItems then menu:updateItems() end
end

function kotranslate:getMode()
    local mode = self:getSetting("mode", "microsoft_free")
    if mode ~= "google_free" and mode ~= "microsoft_free" then
        return "microsoft_free"
    end
    return mode
end

function kotranslate:getSourceLang()
    return self:getSetting("source_lang", "auto")
end

function kotranslate:getTargetLang()
    return self:getSetting("target_lang", "zh")
end

-- Keep requests below the common free web-engine request limit.
function kotranslate:getTranslationChunkLimit()
    local limits = {
        google_free = 1700,
        microsoft_free = 4500,
    }
    return limits[self:getMode()] or 4500
end

function kotranslate:isEnglishAssistEnabled()
    return self:isAssistEnabled()
        and self:getSetting("assist_english_exam", false) == true
end

function kotranslate:isJapaneseAssistEnabled()
    local mode = self:getJapaneseAssistMode()
    return mode == "furigana" or mode == "both"
end

function kotranslate:isJapaneseRomajiEnabled()
    local mode = self:getJapaneseAssistMode()
    return mode == "romaji" or mode == "both"
end

function kotranslate:getJapaneseAssistMode()
    if not self:isAssistEnabled() then return "off" end
    local saved_furigana = self:getSetting("assist_japanese_furigana")
    local saved_romaji = self:getSetting("assist_japanese_romaji")
    if saved_furigana ~= nil or saved_romaji ~= nil then
        local furigana = saved_furigana == true
        local romaji = saved_romaji == true
        if furigana and romaji then return "both" end
        if romaji then return "romaji" end
        if furigana then return "furigana" end
        return "off"
    end
    return "furigana"
end

function kotranslate:isAssistEnabled()
    if not self:isPluginEnabled() then return false end
    return self:getSetting("assist_reading", false) == true
end

function kotranslate:lookupAssistBatch(kind, words)
    local results = {}
    local pending = {}
    local profile = kind == "english_exam"
        and self:getSetting("english_exam_profile", "cet4") or nil
    -- Version Japanese annotation cache keys independently from translations.
    -- Older plugin builds could cache a partial reading (e.g. 恐怖 -> ふ);
    -- those values must never override the corrected dictionary pipeline.
    local cache_kind = (kind == "japanese_furigana"
        or kind == "japanese_romaji") and (kind .. "_v5")
        or kind == "english_exam" and (kind .. "_v2_" .. profile)
        or kind
    self._assist_memory_cache = self._assist_memory_cache or {}
    for _, word in ipairs(words or {}) do
        if results[word] == nil then
            local memory_key = cache_kind .. "\0" .. word
            local memory_value = self._assist_memory_cache[memory_key]
            if memory_value ~= nil then
                results[word] = memory_value or false
            else
                local cached = self:isCacheEnabled()
                    and self.cache:lookupAnnotation(cache_kind, word) or nil
                if cached ~= nil then
                    results[word] = cached
                    self._assist_memory_cache[memory_key] = cached
                else
                    table.insert(pending, word)
                end
            end
        end
    end
    -- Keep dictionary lookups local, but use reasonably large batches so ruby
    -- generation does not turn into one process invocation per word.
    -- Keep each blocking sdcv slice short on low-power Kindles. The reading
    -- worker yields between slices, so page turns and the inactivity timer
    -- continue to be processed while a new page is being annotated.
    local batch_size = 24
    for start = 1, #pending, batch_size do
        if self._reading_hint_coroutine
            and coroutine.running() == self._reading_hint_coroutine then
            coroutine.yield()
        end
        local batch = {}
        for index = start, math.min(start + batch_size - 1, #pending) do
            table.insert(batch, pending[index])
        end
        local fetched = Assist.lookupLocal(kind, batch, profile)
        for _, word in ipairs(batch) do
            local value = fetched[word] or false
            results[word] = value
            self._assist_memory_cache[cache_kind .. "\0" .. word] = value
            if value and self:isCacheEnabled() then
                -- The whole-book worker writes translation rows in a separate
                -- process.  Do not compete for the same SQLite writer lock
                -- while a page is building pronunciation hints.
                if not (self._translation_progress and self._translation_progress.active) then
                    self.cache:storeAnnotation(cache_kind, word, value)
                end
            end
        end
    end
    return results
end

-- Reader-facing document and overlay operations live in kotranslate_reader.lua.

function kotranslate:buildAssistMenu()
    local function refresh_for_assist(force)
        self:applyReadingLineSpacing()
        self:resetRubyPaintCache()
        self:scheduleReadingHints(0.01)
    end

    local function refresh_after_install()
        self._assist_memory_cache = nil
        if Assist.clearLookupCache then Assist.clearLookupCache() end
        self:resetRubyPaintCache()
        self:scheduleReadingHints(0.01)
    end
    local japanese = {
        {
            text = "假名",
            checkbox = true,
            checked_func = function()
                return self:getSetting("assist_japanese_furigana", true) == true
            end,
            callback = function()
                self:saveSetting("assist_reading", true)
                self:saveSetting("assist_japanese_furigana",
                    self:getSetting("assist_japanese_furigana", true) ~= true)
                refresh_for_assist()
            end,
        },
        {
            text = "罗马音",
            checkbox = true,
            checked_func = function()
                return self:getSetting("assist_japanese_romaji", false) == true
            end,
            callback = function()
                self:saveSetting("assist_reading", true)
                self:saveSetting("assist_japanese_romaji",
                    self:getSetting("assist_japanese_romaji", false) ~= true)
                refresh_for_assist()
            end,
        },
    }
    for _, item in ipairs(Dictionaries.buildMenu(refresh_after_install, "字典")) do
        table.insert(japanese, item)
    end

    local english = {
        {
            text = "关闭",
            radio = true,
            checked_func = function() return not self:isEnglishAssistEnabled() end,
            callback = function()
                self:saveSetting("assist_english_exam", false)
                refresh_for_assist()
            end,
        },
    }
    for _, choice in ipairs({
        { value = "cet4", label = "CET4" },
        { value = "cet6", label = "CET6" },
        { value = "tem8", label = "专八" },
        { value = "toefl", label = "TOEFL" },
        { value = "ielts", label = "IELTS" },
    }) do
        table.insert(english, {
            text_func = function()
                return Dictionaries.englishExamStatus(choice.value, choice.label)
            end,
            radio = true,
            checked_func = function()
                return self:isEnglishAssistEnabled()
                    and self:getSetting("english_exam_profile", "cet4") == choice.value
            end,
            keep_menu_open = true,
            callback = function(menu)
                self:saveSetting("assist_reading", true)
                self:saveSetting("assist_english_exam", true)
                self:saveSetting("english_exam_profile", choice.value)
                Dictionaries.downloadEnglishExam(choice.value, menu, function()
                    refresh_after_install()
                    refresh_for_assist()
                end)
            end,
        })
    end

    local settings = {
        self:inlineStyleMenu("assist_font_size", "字号", {
            { value = 30, label = "30%" },
            { value = 35, label = "35%" },
            { value = 40, label = "40%" },
            { value = 50, label = "50%" },
            { value = 60, label = "60%" },
        }),
        self:inlineStyleMenu("assist_color", "颜色", {
            { value = "#999999", label = "40% 灰" },
            { value = "#888888", label = "55% 灰" },
            { value = "#666666", label = "60% 灰" },
            { value = "#4d4d4d", label = "70% 灰" },
            { value = "#333333", label = "80% 灰" },
        }),
    }
    return {
        { text = "日文", sub_item_table = japanese },
        { text = "英文", sub_item_table = english },
        { text = "设置", sub_item_table = settings },
    }
end

function kotranslate:buildTranslationSettingsMenu()
    return {
        {
            text_func = function()
                return "翻译服务：" .. Providers.getProviderName(self:getMode())
            end,
            sub_item_table = self:buildProviderSelector(),
        },
        {
            text_func = function()
                local source = self:getSourceLang()
                return "源语言：" .. (source == "auto" and "自动"
                    or Languages.getNameByCode(source))
            end,
            callback = function() self:showLanguageSelector("source") end,
        },
        {
            text_func = function()
                local target = self:getTargetLang()
                return "目标语言：" .. (target == "zh" and "中文"
                    or Languages.getNameByCode(target))
            end,
            callback = function() self:showLanguageSelector("target") end,
        },
    }
end

function kotranslate:buildTranslationStyleMenu()
    return {
        {
            text_func = function() return "字号：" .. self:getInlineFontSize() end,
            callback = function() self:showInlineFontDialog() end,
        },
        {
            text_func = function()
                local family = self:getSetting("inline_font_family")
                return "字体：" .. (family and family ~= "" and family or "跟随原文")
            end,
            sub_item_table_func = function()
                return self:buildTranslationFontMenu()
            end,
        },
        self:inlineStyleMenu("inline_color", "颜色", {
            { value = "#e6e6e6", label = "10% 灰" },
            { value = "#cccccc", label = "20% 灰" },
            { value = "#b3b3b3", label = "30% 灰" },
            { value = "#999999", label = "40% 灰" },
            { value = "#808080", label = "50% 灰" },
            { value = "#666666", label = "60% 灰" },
            { value = "#4d4d4d", label = "70% 灰" },
            { value = "#333333", label = "80% 灰" },
            { value = "#1a1a1a", label = "90% 灰" },
        }),
    }
end

function kotranslate:buildTranslationFontMenu()
    local items = {
        {
            text = "跟随原文",
            radio = true,
            checked_func = function()
                local family = self:getSetting("inline_font_family")
                return family == nil or family == ""
            end,
            callback = function()
                self:saveSetting("inline_font_family", nil)
                self:applyAssistRuntimeStyle()
            end,
        },
    }
    local ok, cre = pcall(function()
        return require("document/credocument"):engineInit()
    end)
    local faces = ok and cre and cre.getFontFaces and cre.getFontFaces() or {}
    table.sort(faces, function(a, b)
        return tostring(a):lower() < tostring(b):lower()
    end)
    for _, value in ipairs(faces) do
        local face = value
        table.insert(items, {
            text = face,
            radio = true,
            checked_func = function()
                return self:getSetting("inline_font_family") == face
            end,
            callback = function()
                self:saveSetting("inline_font_family", face)
                self:applyAssistRuntimeStyle()
            end,
        })
    end
    items.max_per_page = 8
    return items
end

function kotranslate:buildDataMenu()
    local menu = {
        {
            text_func = function()
                local source = self:getSourceLang()
                local source_name = source == "auto" and "自动"
                    or Languages.getNameByCode(source)
                local provider_name = self:getMode() == "microsoft_free"
                    and "Edge" or "Google"
                return string.format("翻译：%s｜%s → %s",
                    provider_name, source_name,
                    self:getTargetLang() == "zh" and "中文"
                        or Languages.getNameByCode(self:getTargetLang()))
            end,
            sub_item_table = self:buildTranslationSettingsMenu(),
        },
        {
            text = "译文样式",
            sub_item_table = self:buildTranslationStyleMenu(),
        },
        {
            text = "任务队列",
            callback = function() self:showTranslationQueue() end,
        },
    }
    table.insert(menu, {
        text = "删除本书译文",
        enabled_func = function()
            local path = self.ui and self.ui.document and self.ui.document.file
            return path and self:hasTranslationOverlay(path) or false
        end,
        callback = function() self:confirmClearCache() end,
    })
    return menu
end

function kotranslate:addToMainMenu(menu_items)
    menu_items.kotranslate = {
        text = _("KoTranslate"),
        checkbox = true,
        checked_func = function() return self:isPluginEnabled() end,
        hold_callback = function(menu) self:togglePluginEnabled(menu) end,
        sorting_hint = "tools",
        sub_item_table = self:buildMenuTable(),
    }
end

function kotranslate:buildMenuTable()
    local menu = {
        {
            text = "生成译文（本书）",
            enabled_func = function()
                return self:isWholeBookTranslationSupported()
            end,
            callback = function()
                self:translateBook(true)
            end,
        },
        {
            text = "生成译文（本章）",
            enabled_func = function()
                local path = self.ui and self.ui.document and self.ui.document.file
                return path and path:lower():match("%.epub$") ~= nil
            end,
            callback = function()
                self:translateBook(false)
            end,
        },
        {
            text = "中文译文",
            checkbox = true,
            checked_func = function()
                local path = self.ui and self.ui.document and self.ui.document.file
                return path and self:hasTranslationOverlay(path)
                    and self:getSetting("translation_visible", true) == true or false
            end,
            enabled_func = function()
                local path = self.ui and self.ui.document and self.ui.document.file
                return path and self:hasTranslationOverlay(path) or false
            end,
            callback = function() self:toggleTranslationVisible() end,
        },
        {
            text = "辅助阅读",
            checkbox = true,
            checked_func = function() return self:isAssistEnabled() end,
            -- Normal tap opens the language-specific submenu. Long-press is
            -- deliberately reserved for the master switch.
            hold_callback = function(menu) 
                local enabled = not self:isAssistEnabled()
                self:saveSetting("assist_reading", enabled)
                self:applyReadingLineSpacing()
                self:resetRubyPaintCache()
                self:scheduleReadingHints(0.01)
                if menu and menu.updateItems then menu:updateItems() end
            end,
            sub_item_table = self:buildAssistMenu(),
        },
        {
            text = "设置与数据",
            sub_item_table = self:buildDataMenu(),
        },
    }
    
    return menu
end

function kotranslate:buildProviderSelector()
    local items = {}
    for i, provider in ipairs(Providers.list) do
        local pid = provider.id

        table.insert(items, {
            text_func = function()
                return provider.name
            end,
            checked_func = function()
                return self:getMode() == pid
            end,
            enabled_func = function()
                return true
            end,
            radio = true,
            callback = function()
                self:saveSetting("mode", pid)
                self:syncTranslateOverride()
                TranslationUI.showInfo(T(_("Provider: %1"), provider.name))
            end,
        })
    end
    return items
end

------------------------------------------------------------------------
-- Toggle cache
------------------------------------------------------------------------
------------------------------------------------------------------------
-- Language selector
------------------------------------------------------------------------
function kotranslate:showLanguageSelector(which)
    local Menu = require("ui/widget/menu")
    local item_table = {}

    -- Add "Auto-detect" option for source language
    if which == "source" then
        table.insert(item_table, {
            text = _("Auto-detect"),
            callback = function()
                self:saveSetting("source_lang", "auto")
                TranslationUI.showInfo(_("Source: Auto-detect"))
            end,
        })
    end

    for _, lang in ipairs(Languages.list) do
        table.insert(item_table, {
            text = lang.name .. " (" .. lang.code .. ")",
            callback = function()
                if which == "source" then
                    self:saveSetting("source_lang", lang.code)
                else
                    self:saveSetting("target_lang", lang.code)
                end
                local sl = self:getSourceLang()
                local sl_name = sl == "auto" and _("Auto") or Languages.getNameByCode(sl)
                TranslationUI.showInfo(
                    sl_name .. " → " .. Languages.getNameByCode(self:getTargetLang())
                )
            end,
        })
    end

    local menu
    menu = Menu:new{
        title = which == "source" and _("Source Language") or _("Target Language"),
        item_table = item_table,
        width = math.floor(Screen:getWidth() * 0.8),
        height = math.floor(Screen:getHeight() * 0.8),
        close_callback = function() UIManager:close(menu) end,
    }
    UIManager:show(menu)
end

-------------------------------------------------------------------------
-- Translate input text
------------------------------------------------------------------------
------------------------------------------------------------------------
-- Clear cache
------------------------------------------------------------------------
function kotranslate:confirmClearCache()
    local ButtonDialog = require("ui/widget/buttondialog")
    local dialog
    dialog = ButtonDialog:new{
        title = "删除本书译文",
        text = "彻底删除当前书的全部译文数据？原书不会被修改。",
        buttons = {
            {
                {
                    text = _("Cancel"),
                    callback = function()
                        UIManager:close(dialog)
                    end,
                },
                {
                    text = "删除",
                    callback = function()
                        local book_path = self.ui and self.ui.document and self.ui.document.file
                        if not self:clearTranslationQueueForBook(book_path) then
                            UIManager:close(dialog)
                            TranslationUI.showInfo("这本书正在翻译，请在任务结束后再清除。")
                            return
                        end
                        local removed, cleared_path, overlay = self:removeTranslationDataForBook(book_path)
                        self.cache:clearForBook(cleared_path or book_path, overlay)
                        self:saveSetting("translation_visible", false)
                        UIManager:close(dialog)
                        if self.ui and self.ui.document then
                            self.ui.document._kotranslate_extra_css = nil
                        end
                        self:applyAssistRuntimeStyle()
                        TranslationUI.showInfo(removed > 0
                            and "已彻底删除本书译文"
                            or "已清除本书译文数据库记录")
                    end,
                },
            },
        },
    }
    UIManager:show(dialog)
end

function kotranslate:onCloseDocument()
    self._style_refresh_pending = nil
    self._reading_hint_generation = (self._reading_hint_generation or 0) + 1
    self._reading_hint_coroutine = nil
    self._reading_hint_job_pending = false
    self._reading_hint_scheduled_key = nil
    self:resetRubyPaintCache()
    self.cache:close()
end

-- CREngine can emit a page/position update before it has finished laying out
-- every visible line.  Computing here synchronously used to cache only the
-- first part of a page, so later paragraphs never received auxiliary hints.
-- Coalesce updates and wait briefly for the layout to settle before caching.
function kotranslate:scheduleReadingHints(delay)
    -- When the master switch is off there is nothing to compute.  Previously
    -- paintTo() kept seeing an unset page marker, scheduling another empty
    -- computation and forcing another full-screen refresh forever.
    if not self:isAssistEnabled() then
        self._reading_hint_job_pending = false
        self._reading_hint_scheduled_key = nil
        self._reading_hints = {}
        local document = self.ui and self.ui.document
        self._reading_page = document and document:getCurrentPage() or nil
        self._reading_document = document and tostring(document.file or "") or nil
        return
    end
    local scheduled_document = self.ui and self.ui.document
    local scheduled_key = scheduled_document
        and (tostring(scheduled_document.file or "") .. "\0"
            .. tostring(scheduled_document:getCurrentPage())) or nil
    if self._reading_hint_job_pending
        and scheduled_key == self._reading_hint_scheduled_key then return end
    self._reading_hint_generation = (self._reading_hint_generation or 0) + 1
    local generation = self._reading_hint_generation
    self._reading_hint_job_pending = true
    self._reading_hint_scheduled_key = scheduled_key
    UIManager:scheduleIn(delay or 0.01, function()
        if generation ~= self._reading_hint_generation then return end
        if not self.ui or not self.ui.document then return end
        local target_document = tostring(self.ui.document.file or "")
        local target_page = self.ui.document:getCurrentPage()
        local worker
        worker = coroutine.create(function()
            self:computeReadingHints()
        end)
        self._reading_hint_coroutine = worker
        local function resume_worker()
            if generation ~= self._reading_hint_generation
                or not self.ui or not self.ui.document
                or tostring(self.ui.document.file or "") ~= target_document
                or self.ui.document:getCurrentPage() ~= target_page then
                if self._reading_hint_coroutine == worker then
                    self._reading_hint_coroutine = nil
                end
                self._reading_hint_job_pending = false
                self._reading_hint_scheduled_key = nil
                return
            end
            local ok, err = coroutine.resume(worker)
            if not ok then
                logger.err("kotranslate: reading worker failed", tostring(err))
                self._reading_hint_coroutine = nil
                self._reading_hint_job_pending = false
                self._reading_hint_scheduled_key = nil
                return
            end
            if coroutine.status(worker) == "dead" then
                self._reading_hint_coroutine = nil
                self._reading_hint_job_pending = false
                self._reading_hint_scheduled_key = nil
                UIManager:setDirty("all", "ui")
            else
                UIManager:scheduleIn(0.01, resume_worker)
            end
        end
        resume_worker()
    end)
end

function kotranslate:onReaderReady()
    if self.view and self.view.registerViewModule then
        self.view:registerViewModule("kotranslate_readings", self)
    end
    UIManager:nextTick(function()
        -- Pronunciation is a framebuffer overlay.  Do not submit a stylesheet
        -- here: ReaderReady is emitted again after a full style reload and
        -- doing so created an endless "style requires full reload" loop.
        if self.applyReadingLineSpacing then self:applyReadingLineSpacing() end
        if self.scheduleReadingHints then self:scheduleReadingHints(0.05) end
    end)
end

-- Restore the saved translation layer while CREngine is still loading its
-- document settings. Applying the same CSS after ReaderReady makes the built
-- DOM stale and triggers KOReader's full-reload prompt; at this stage it is
-- part of the initial render and appears immediately without a toggle cycle.
function kotranslate:onReadSettings()
    local path = self.ui and self.ui.document and self.ui.document.file
    if path and self:hasTranslationOverlay(path)
        and self:getSetting("translation_visible", true) == true then
        self:applyAssistRuntimeStyle(true)
    end
end

function kotranslate:onDocumentReady()
    -- The source document remains open; overlays are restored in
    -- onReadSettings without opening a generated companion file.
end

function kotranslate:onPageUpdate()
    if self:isAssistEnabled() and self.scheduleReadingHints then
        self:scheduleReadingHints(0.01)
    end
end

function kotranslate:onPosUpdate()
    if self:isAssistEnabled() and self.scheduleReadingHints then
        self:scheduleReadingHints(0.01)
    end
end

function kotranslate:onDocumentRerendered()
    self:resetRubyPaintCache()
    if self:isAssistEnabled() and self.scheduleReadingHints then
        self:scheduleReadingHints(0.05)
    end
end

kotranslate.onDocumentPartiallyRerendered = kotranslate.onDocumentRerendered

return kotranslate
